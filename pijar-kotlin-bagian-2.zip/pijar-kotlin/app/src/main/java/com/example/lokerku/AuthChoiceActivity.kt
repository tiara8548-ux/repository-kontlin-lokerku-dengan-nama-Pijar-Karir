package com.example.lokerku

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Welcome screen; authentication flows continue in the existing activities. */
class AuthChoiceActivity : AppCompatActivity() {
    private fun dp(n: Int) = (resources.displayMetrics.density * n + .5f).toInt()
    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value; textSize = size.toFloat(); setTextColor(color)
            typeface = if (bold) AppFont.semibold(this@AuthChoiceActivity) else AppFont.regular(this@AuthChoiceActivity)
        }
    private fun action(title: String, primary: Boolean): Button = Button(this).apply {
        text = title; isAllCaps = false; textSize = 15f
        setTextColor(if (primary) Color.WHITE else PijarStyle.PURPLE)
        typeface = AppFont.semibold(this@AuthChoiceActivity); minHeight = dp(54)
        backgroundTintList = null; stateListAnimator = null
        background = PijarStyle.surface(this@AuthChoiceActivity, if (primary) PijarStyle.PURPLE else PijarStyle.LAVENDER, 16f)
    }
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = PijarStyle.CREAM; window.navigationBarColor = PijarStyle.PURPLE_DARK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val scroll = ScrollView(this).apply { isFillViewport = true; setBackgroundColor(PijarStyle.CREAM) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24),dp(28),dp(24),dp(28))
        }
        scroll.addView(root)
        root.addView(label("✦  PIJAR KARIER",13,PijarStyle.PURPLE,true).apply { letterSpacing = .08f })
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(24),dp(28),dp(24),dp(28))
            background = PijarStyle.gradient(this@AuthChoiceActivity,PijarStyle.PURPLE_DARK,0xff794dc4.toInt(),28f)
        }
        root.addView(hero, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,dp(24),0,dp(24)) })
        val pill = label("✦  UNTUK LANGKAHMU",10,PijarStyle.INK,true).apply {
            setPadding(dp(12),dp(7),dp(12),dp(7)); background = PijarStyle.surface(this@AuthChoiceActivity,PijarStyle.MINT,18f)
        }
        hero.addView(pill,LinearLayout.LayoutParams(-2,-2))
        val title = label("Karier baru\nberawal di sini.",29,Color.WHITE,true).apply { setLineSpacing(dp(2).toFloat(),1f) }
        hero.addView(title,LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(24) })
        val desc = label("Temukan peluang yang pas dan siapkan langkah terbaikmu.",14,0xfff1eafd.toInt(),false).apply {
            setLineSpacing(dp(3).toFloat(),1f)
        }
        hero.addView(desc,LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(12) })
        hero.addView(label("✳    ●    ✦",23,0xffffb6a5.toInt(),true),LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(24) })
        root.addView(label("Mulai perjalananmu",20,PijarStyle.INK,true))
        root.addView(label("Masuk atau buat akun untuk melanjutkan.",13,PijarStyle.MUTED,false),
            LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,dp(5),0,dp(20)) })
        val login = action("Masuk",true); root.addView(login,LinearLayout.LayoutParams(-1,-2))
        val register = action("Buat akun",false)
        root.addView(register,LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(10) })
        login.setOnClickListener { startActivity(Intent(this,LoginActivity::class.java)) }
        register.setOnClickListener { startActivity(Intent(this,RegisterActivity::class.java)) }
        setContentView(scroll); FontEnforcer.apply(root,this); UiMotion.styleButtons(root); UiMotion.reveal(hero,50)
    }
    override fun onPause() { UiMotion.finishReveals(window.decorView); super.onPause() }
}
