package com.example.lokerku;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private static final String URL_REGISTER =
            "https://ahannaja.cu.ma/lokerku_api/auth/register.php";

    private static final int NAVY = Color.rgb(21, 26, 61);
    private static final int BLUE = PijarStyle.PURPLE_DARK;
    private static final int TEAL = PijarStyle.PURPLE;
    private static final int BG = Color.rgb(247, 248, 255);
    private static final int TEXT = Color.rgb(21, 26, 61);
    private static final int MUTED = Color.rgb(104, 112, 143);
    private static final int WHITE = Color.WHITE;

    private EditText etName;
    private EditText etUsername;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private EditText etPhone;

    private Button btnRegister;
    private ProgressBar progressBar;
    private TextView tvLogin;

    private boolean requestRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(0xff3b225f);
        getWindow().setNavigationBarColor(0xff3b225f);
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                    0);
        }

        buatTampilan();
    }

    private void buatTampilan() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.TRANSPARENT);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(18), dp(22), dp(24));
        root.setBackgroundColor(Color.TRANSPARENT);

        scrollView.addView(root);

        TextView tvBack = new TextView(this);
        tvBack.setText("‹  Kembali");
        tvBack.setTextSize(15);
        tvBack.setTextColor(WHITE);
        tvBack.setTypeface(AppFont.semibold(this));
        tvBack.setGravity(Gravity.CENTER_VERTICAL);
        tvBack.setPadding(0, dp(6), 0, dp(12));

        root.addView(
                tvBack,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(42)
                )
        );

        tvBack.setOnClickListener(v -> finish());

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Buat Akun Baru");
        tvTitle.setTextSize(26);
        tvTitle.setTextColor(WHITE);
        tvTitle.setTypeface(AppFont.semibold(this));

        LinearLayout.LayoutParams titleParams =
                new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(24);

        root.addView(tvTitle, titleParams);

        TextView tvSubtitle = new TextView(this);
        tvSubtitle.setText(
                "Lengkapi data berikut untuk mulai mencari pekerjaan."
        );
        tvSubtitle.setTextSize(13);
        tvSubtitle.setTextColor(0xffe2ebff);

        LinearLayout.LayoutParams subtitleParams =
                new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(7);

        root.addView(tvSubtitle, subtitleParams);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(24), dp(22), dp(24));
        GradientDrawable cardBackground = AuthGlass.card(this);
        card.setBackground(cardBackground);
        card.setElevation(dp(3));

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = dp(20);

        root.addView(card, cardParams);

        GoogleDesign.addTo(card, this, "Daftar dengan Google");
        TextView separator = new TextView(this); separator.setText("ATAU ISI DATA MANUAL");
        separator.setTextSize(10); separator.setTextColor(0xffd7e5ff); separator.setLetterSpacing(.08f);
        separator.setGravity(Gravity.CENTER); separator.setPadding(0,dp(18),0,dp(14)); card.addView(separator);

        etName = tambahField(
                card,
                "Nama lengkap",
                "Masukkan nama lengkap",
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_CAP_WORDS,
                false
        );

        etUsername = tambahField(
                card,
                "Username",
                "Buat username",
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
                false
        );

        etEmail = tambahField(
                card,
                "Email",
                "nama@email.com",
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
                false
        );

        etPhone = tambahField(
                card,
                "Nomor HP",
                "Contoh: 08xxxxxxxxxx",
                InputType.TYPE_CLASS_PHONE,
                false
        );

        etPassword = tambahField(
                card,
                "Password",
                "Minimal 6 karakter",
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_PASSWORD,
                false
        );

        etConfirmPassword = tambahField(
                card,
                "Konfirmasi password",
                "Ulangi password",
                InputType.TYPE_CLASS_TEXT
                        | InputType.TYPE_TEXT_VARIATION_PASSWORD,
                true
        );

        btnRegister = new Button(this);
        btnRegister.setText("Daftar Sekarang");
        btnRegister.setTextSize(15);
        btnRegister.setTextColor(WHITE);
        btnRegister.setAllCaps(false);
        btnRegister.setTypeface(AppFont.semibold(this));
        btnRegister.setBackgroundTintList(null);
        btnRegister.setBackground(gradientBackground(BLUE, TEAL, dp(18)));
        btnRegister.setStateListAnimator(null);

        LinearLayout.LayoutParams registerParams =
                new LinearLayout.LayoutParams(-1, -2);
        btnRegister.setMinHeight(dp(52));
        registerParams.topMargin = dp(22);

        card.addView(btnRegister, registerParams);
        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        progressBar.setIndeterminateTintList(
                ColorStateList.valueOf(TEAL)
        );
        progressBar.setVisibility(View.GONE);

        LinearLayout.LayoutParams progressParams =
                new LinearLayout.LayoutParams(dp(30), dp(30));
        progressParams.gravity = Gravity.CENTER_HORIZONTAL;
        progressParams.topMargin = dp(12);

        card.addView(progressBar, progressParams);

        LinearLayout loginRow = new LinearLayout(this);
        loginRow.setOrientation(LinearLayout.HORIZONTAL);
        loginRow.setGravity(Gravity.CENTER);
        loginRow.setPadding(0, dp(20), 0, 0);

        TextView tvHaveAccount = new TextView(this);
        tvHaveAccount.setText("Sudah punya akun? ");
        tvHaveAccount.setTextColor(0xffe2ebff);
        tvHaveAccount.setTextSize(13);

        loginRow.addView(tvHaveAccount);

        tvLogin = new TextView(this);
        tvLogin.setText("Masuk");
        tvLogin.setTextColor(WHITE);
        tvLogin.setTextSize(13);
        tvLogin.setPadding(dp(8), dp(12), dp(8), dp(12));
        tvLogin.setTypeface(AppFont.semibold(this));

        loginRow.addView(tvLogin);

        root.addView(loginRow);

        TextView tvFooter = new TextView(this);
        tvFooter.setText("MULAI LANGKAH BARUMU");
        tvFooter.setTextColor(0xffd7e5ff);
        tvFooter.setTextSize(10);
        tvFooter.setGravity(Gravity.CENTER);
        tvFooter.setLetterSpacing(0.04f);

        LinearLayout.LayoutParams footerParams =
                new LinearLayout.LayoutParams(-1, -2);
        footerParams.topMargin = dp(22);

        root.addView(tvFooter, footerParams);

        btnRegister.setOnClickListener(v -> registerUser());

        etConfirmPassword.setOnEditorActionListener(
                (v, actionId, event) -> {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        registerUser();
                        return true;
                    }
                    return false;
                }
        );

        tvLogin.setOnClickListener(v -> bukaLogin());

        android.widget.FrameLayout scene = new android.widget.FrameLayout(this);
        scene.addView(new AuthAmbientView(this), new android.widget.FrameLayout.LayoutParams(-1, -1));
        scene.addView(scrollView, new android.widget.FrameLayout.LayoutParams(-1, -1));
        setContentView(scene);
        FontEnforcer.apply(scrollView, this);
        UiMotion.styleButtons(scrollView);
        UiMotion.bindActions(scrollView);
        UiMotion.bindPress(tvBack);
        UiMotion.bindPress(tvLogin);
        UiMotion.revealChildren(root, 60, 85, 7);
        UiMotion.revealChildren(card, 240, 45, 14);
    }

    @Override protected void onPause() {
        UiMotion.finishReveals(getWindow().getDecorView());
        super.onPause();
    }

    private EditText tambahField(
            LinearLayout parent,
            String label,
            String hint,
            int inputType,
            boolean lastField
    ) {
        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(13);
        tvLabel.setTextColor(WHITE);
        tvLabel.setTypeface(AppFont.semibold(this));

        LinearLayout.LayoutParams labelParams =
                new LinearLayout.LayoutParams(-1, -2);
        labelParams.topMargin = parent.getChildCount() == 0
                ? 0 : dp(15);

        parent.addView(tvLabel, labelParams);

        EditText editText = new EditText(this);
        editText.setSingleLine(true);
        editText.setTextSize(14);
        editText.setTextColor(WHITE);
        editText.setHintTextColor(0xffc8d7f5);
        editText.setHint(hint);
        editText.setInputType(inputType);
        editText.setTypeface(AppFont.regular(this));
        editText.setPadding(dp(13), dp(10), dp(13), dp(10));
        editText.setMinHeight(dp(52));
        GradientDrawable inputBackground = AuthGlass.field(this, false);
        editText.setBackgroundTintList(null);
        editText.setBackground(inputBackground);
        editText.setOnFocusChangeListener((field, focused) -> {
            inputBackground.setStroke(dp(focused ? 2 : 1), focused ? 0xffd4eeff : 0x99c6dcff);
            android.animation.ObjectAnimator lift = android.animation.ObjectAnimator.ofFloat(
                    field, View.TRANSLATION_Z, focused ? dp(3) : 0f);
            lift.setDuration(220);
            lift.start();
        });
        editText.setImeOptions(
                lastField
                        ? EditorInfo.IME_ACTION_DONE
                        : EditorInfo.IME_ACTION_NEXT
        );

        LinearLayout.LayoutParams inputParams =
                new LinearLayout.LayoutParams(-1, -2);
        inputParams.topMargin = dp(7);

        parent.addView(editText, inputParams);

        return editText;
    }

    private void registerUser() {
        if (requestRunning) {
            return;
        }

        final String nama =
                etName.getText().toString().trim();
        final String username =
                etUsername.getText().toString().trim();
        final String email =
                etEmail.getText().toString().trim();
        final String phone =
                etPhone.getText().toString().trim();
        final String password =
                etPassword.getText().toString();
        final String confirmPassword =
                etConfirmPassword.getText().toString();

        if (nama.isEmpty()) {
            etName.setError("Nama lengkap wajib diisi");
            etName.requestFocus();
            return;
        }

        if (username.length() < 4) {
            etUsername.setError("Username minimal 4 karakter");
            etUsername.requestFocus();
            return;
        }

        if (email.isEmpty()
                || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Masukkan alamat email yang valid");
            etEmail.requestFocus();
            return;
        }

        if (phone.isEmpty()) {
            etPhone.setError("Nomor HP wajib diisi");
            etPhone.requestFocus();
            return;
        }

        if (!phone.matches("[0-9+() -]{8,20}")) {
            etPhone.setError("Periksa format nomor HP");
            etPhone.requestFocus();
            return;
        }

        if (password.length() < 6) {
            etPassword.setError("Password minimal 6 karakter");
            etPassword.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Password tidak sama");
            etConfirmPassword.requestFocus();
            return;
        }

        aturLoading(true);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                URL_REGISTER,
                response -> {
                    aturLoading(false);

                    try {
                        JSONObject json = new JSONObject(response);

                        boolean success = json.optBoolean(
                                "success",
                                false
                        );

                        String message = json.optString(
                                "message",
                                "Respons server tidak diketahui."
                        );

                        Toast.makeText(
                                RegisterActivity.this,
                                message,
                                Toast.LENGTH_LONG
                        ).show();

                        if (success) {
                            Intent intent = new Intent(
                                    RegisterActivity.this,
                                    LoginActivity.class
                            );

                            intent.addFlags(
                                    Intent.FLAG_ACTIVITY_CLEAR_TOP
                                            | Intent.FLAG_ACTIVITY_SINGLE_TOP
                            );

                            startActivity(intent);
                            finish();
                        }

                    } catch (Exception e) {
                        Toast.makeText(
                                RegisterActivity.this,
                                "Respons server tidak valid. Periksa JSON API.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                },
                error -> {
                    aturLoading(false);

                    String message =
                            "Registrasi gagal terhubung ke server.";

                    if (error.networkResponse != null) {
                        message += " HTTP "
                                + error.networkResponse.statusCode;
                    } else if (error.getMessage() != null) {
                        message += " " + error.getMessage();
                    }

                    Toast.makeText(
                            RegisterActivity.this,
                            message,
                            Toast.LENGTH_LONG
                    ).show();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                params.put("nama", nama);
                params.put("username", username);
                params.put("email", email);
                params.put("password", password);
                params.put("no_hp", phone);

                return params;
            }
        };

        request.setRetryPolicy(
                new DefaultRetryPolicy(
                        15000,
                        1,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
        );

        Volley.newRequestQueue(getApplicationContext()).add(request);
    }

    private void aturLoading(boolean loading) {
        requestRunning = loading;

        progressBar.setVisibility(
                loading ? View.VISIBLE : View.GONE
        );

        btnRegister.setEnabled(!loading);
        btnRegister.setAlpha(loading ? 0.65f : 1.0f);
        btnRegister.setText(
                loading ? "Mendaftarkan akun..." : "Daftar Sekarang"
        );

        etName.setEnabled(!loading);
        etUsername.setEnabled(!loading);
        etEmail.setEnabled(!loading);
        etPhone.setEnabled(!loading);
        etPassword.setEnabled(!loading);
        etConfirmPassword.setEnabled(!loading);
        tvLogin.setEnabled(!loading);
    }

    private void bukaLogin() {
        Intent intent = new Intent(
                RegisterActivity.this,
                LoginActivity.class
        );

        intent.addFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP
        );

        startActivity(intent);
        finish();
    }

    private GradientDrawable roundBackground(
            int color,
            int radius
    ) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);

        return drawable;
    }

    private GradientDrawable gradientBackground(
            int startColor,
            int endColor,
            int radius
    ) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{startColor, endColor}
        );

        drawable.setCornerRadius(radius);

        return drawable;
    }

    private int dp(float value) {
        return (int) (
                value * getResources()
                        .getDisplayMetrics().density + 0.5f
        );
    }
}
