package com.example.lokerku

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    private var splashView: LokerKuSplashView? = null
    private var sudahPindah = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = PijarStyle.PURPLE_DARK
        window.navigationBarColor = PijarStyle.PURPLE_DARK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN
        splashView = LokerKuSplashView(this).also { view ->
            view.setAnimationListener {
                if (!isFinishing && !sudahPindah) {
                    sudahPindah = true
                    startActivity(Intent(this, AuthChoiceActivity::class.java))
                    @Suppress("DEPRECATION")
                    overridePendingTransition(R.anim.screen_enter, R.anim.screen_exit)
                    finish()
                }
            }
            setContentView(view)
        }
    }

    override fun onPause() { splashView?.pauseAnimations(); super.onPause() }
    override fun onResume() { super.onResume(); splashView?.resumeAnimations() }
    override fun onDestroy() { splashView?.stopAnimations(); super.onDestroy() }
}
