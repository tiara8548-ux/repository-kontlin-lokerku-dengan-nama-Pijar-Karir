package com.example.lokerku;

import android.content.Context;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

final class ApiClient {
    static final String BASE="https://ahannaja.cu.ma/lokerku_api/";
    interface Result { void success(JSONObject json); void fail(String msg); }
    static void post(Context c,String path,Map<String,String> values,Result cb){
        String session=SessionStore.get(c); if(session.isEmpty()){cb.fail("Sesi tidak tersedia. Masuk kembali.");return;}
        Map<String,String> p=new HashMap<>(values); p.put("session_token",session);
        StringRequest request=new StringRequest(Request.Method.POST,BASE+path,response -> {
            try {JSONObject json=new JSONObject(response); if(json.optBoolean("success")) cb.success(json); else cb.fail(json.optString("message","Permintaan gagal."));}
            catch(Exception e){cb.fail("Respons server tidak valid.");}
        },error -> {
            String message="Tidak dapat menghubungi server.";
            if(error.networkResponse!=null && error.networkResponse.data!=null) try { message=new JSONObject(new String(error.networkResponse.data,StandardCharsets.UTF_8)).optString("message",message); }catch(Exception ignored){}
            cb.fail(message);
        }) { @Override protected Map<String,String> getParams(){return p;} };
        request.setRetryPolicy(new DefaultRetryPolicy(20000,0,1)); Volley.newRequestQueue(c.getApplicationContext()).add(request);
    }
}
