package com.example.lokerku;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Moving layers behind the glass cards; no account data is used here. */
public final class AuthAmbientView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private Shader background; private ValueAnimator animator; private float phase;
    public AuthAmbientView(Context context){super(context);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);}
    private float dp(float n){return n*getResources().getDisplayMetrics().density;}
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){super.onSizeChanged(w,h,ow,oh);
        if(w>0&&h>0)background=new LinearGradient(0,0,w,h,new int[]{0xff3b225f,0xff6d398f,0xff9a527f},null,Shader.TileMode.CLAMP);}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight();if(w<=0||h<=0)return;
        paint.setStyle(Paint.Style.FILL);paint.setShader(background);canvas.drawPaint(paint);paint.setShader(null);
        float drift=(float)Math.sin(phase*Math.PI*2), wave=(float)Math.cos(phase*Math.PI*2);
        glow(canvas,w*.85f+dp(26)*drift,h*.13f+dp(14)*wave,w*.66f,0xaaffb6cb);
        glow(canvas,w*.12f-dp(20)*wave,h*.77f+dp(18)*drift,w*.66f,0xaaa58af4);
        glow(canvas,w*.80f+dp(15)*wave,h*.84f-dp(18)*drift,w*.48f,0x88ffd599);
        paint.setShader(null);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(0x55dceaff);
        canvas.drawCircle(w*.85f+dp(26)*drift,h*.13f+dp(14)*wave,w*.36f,paint);
        canvas.drawCircle(w*.12f-dp(20)*wave,h*.77f+dp(18)*drift,w*.27f,paint);
        paint.setStyle(Paint.Style.FILL);
        for(int i=0;i<8;i++){float x=w*(.09f+.115f*i)+dp(4)*(float)Math.cos(phase*6.28f+i);float y=h*(.13f+.105f*(i%7))+dp(9)*(float)Math.sin(phase*6.28f+i*.7f);
            paint.setColor(i%3==0?0xbbe5f3ff:0x70d6e7ff);canvas.drawCircle(x,y,dp(i%3==0?1.8f:1.1f),paint);}
    }
    private void glow(Canvas c,float x,float y,float r,int color){if(r<=0)return;paint.setShader(new RadialGradient(x,y,r,new int[]{color,0x00000000},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);}
    private void startMotion(){if(animator!=null||(Build.VERSION.SDK_INT>=26&&!ValueAnimator.areAnimatorsEnabled()))return;
        animator=ValueAnimator.ofFloat(0f,1f);animator.setDuration(14000);animator.setInterpolator(new LinearInterpolator());animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.addUpdateListener(a->{phase=(Float)a.getAnimatedValue();invalidate();});animator.start();}
    private void stopMotion(){if(animator!=null){animator.cancel();animator=null;}}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();if(getWindowVisibility()==VISIBLE)startMotion();}
    @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(visibility==VISIBLE&&isAttachedToWindow())startMotion();else stopMotion();}
    @Override protected void onDetachedFromWindow(){stopMotion();super.onDetachedFromWindow();}
}
