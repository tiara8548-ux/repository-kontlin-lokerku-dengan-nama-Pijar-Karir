package com.example.lokerku;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class CertificatesActivity extends AppCompatActivity {
    private LinearLayout list; private ActivityResultLauncher<Intent> picker; private Uri pending; private boolean uploading;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(bold?AppFont.semibold(this):AppFont.regular(this));return t;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);
        picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if(result.getResultCode()!=RESULT_OK || result.getData()==null) return;
            pending=result.getData().getData(); if(pending==null)return;
            EditText label=new EditText(this);label.setSingleLine(true);label.setHint("Contoh: Sertifikat pelatihan");
            new PremiumDialog.Builder(this).setTitle("Judul sertifikat").setMessage("Sertifikat akan dapat dilihat dan diunduh siapa saja. Pastikan data di dalamnya aman untuk dipublikasikan.")
                .setView(label).setNegativeButton("Batal",null).setPositiveButton("Publikasikan",(d,w)->{
                    String name=label.getText().toString().trim();if(name.isEmpty()){toast("Judul sertifikat wajib diisi.");return;} upload(pending,name);
                }).show();
        });
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(0xfff7f8ff);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(26),dp(20),dp(30));scroll.addView(root);
        TextView back=text("‹  Kembali",15,0xff0000cc,true);back.setPadding(0,0,0,dp(22));back.setOnClickListener(v->finish());root.addView(back);
        TextView label=text("PORTOFOLIO  /  PIJAR KARIER",10,0xff0000cc,true);label.setLetterSpacing(.08f);root.addView(label);
        root.addView(text("Sertifikat publik",26,0xff1b273d,true));
        TextView desc=text("Unggah PDF, JPG, atau PNG hingga 5 MB. Siapa saja yang memiliki tautan profil dapat melihat dan mengunduhnya.",13,0xff68708f,false);desc.setPadding(0,dp(8),0,dp(18));root.addView(desc);
        TextView add=text("+  Tambah sertifikat",14,Color.WHITE,true);add.setGravity(Gravity.CENTER);add.setBackground(bg(0xff0000cc,18));root.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));
        add.setOnClickListener(v->{ if(uploading){toast("Unggahan masih berlangsung.");return;} Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","image/jpeg","image/png"});picker.launch(i); });
        TextView share=text("Bagikan profil publik  ↗",13,0xff0000cc,true);share.setGravity(Gravity.CENTER);share.setPadding(dp(12),dp(16),dp(12),dp(14));root.addView(share);
        share.setOnClickListener(v->{int id=getSharedPreferences("lokerku_user",MODE_PRIVATE).getInt("id",0);if(id<=0){toast("Masuk kembali.");return;}Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,ApiClient.BASE+"profile/public.php?id="+id);startActivity(Intent.createChooser(send,"Bagikan profil"));});
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        setContentView(scroll);FontEnforcer.apply(root,this);UiMotion.bindActions(root);UiMotion.revealChildren(root,80,65,6);refresh();
    }
    private void refresh(){
        list.removeAllViews();TextView loading=text("Memuat sertifikat…",12,0xff68708f,false);list.addView(loading);
        Map<String,String> p=new HashMap<>();p.put("action","list");
        ApiClient.post(this,"profile/certificates.php",p,new ApiClient.Result(){
            public void success(JSONObject json){list.removeAllViews();JSONArray a=json.optJSONArray("certificates");
                if(a==null||a.length()==0){list.addView(text("Belum ada sertifikat. Tambahkan pencapaian pertamamu.",13,0xff68708f,false));return;}
                for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c!=null)addCertificate(c);}}
            public void fail(String msg){list.removeAllViews();list.addView(text(msg,12,0xffb52e46,false));}
        });
    }
    private void addCertificate(JSONObject cert){
        final long id=cert.optLong("id",0);if(id<=0)return;
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(18),dp(16),dp(18),dp(14));card.setBackground(bg(Color.WHITE,20));
        card.addView(text(cert.optString("label","Sertifikat"),15,0xff1b273d,true));TextView date=text("Dokumen publik  •  "+cert.optString("created_at",""),11,0xff68708f,false);date.setPadding(0,dp(5),0,dp(10));card.addView(date);
        LinearLayout row=new LinearLayout(this);TextView open=text("Lihat / unduh",13,0xff0000cc,true);open.setPadding(0,dp(6),dp(20),dp(6));row.addView(open);
        TextView del=text("Hapus",13,0xffbf3046,true);del.setPadding(dp(10),dp(6),dp(10),dp(6));row.addView(del);card.addView(row);
        open.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(ApiClient.BASE+"profile/certificate_file.php?id="+id)));}catch(Exception e){toast("Tidak ada aplikasi untuk membuka tautan.");}});
        del.setOnClickListener(v->new PremiumDialog.Builder(this).setTitle("Hapus sertifikat?").setMessage("Dokumen akan dihapus dari profil publik.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{
            Map<String,String> p=new HashMap<>();p.put("action","delete");p.put("certificate_id",Long.toString(id));ApiClient.post(this,"profile/certificates.php",p,new ApiClient.Result(){public void success(JSONObject j){toast("Sertifikat dihapus.");refresh();}public void fail(String m){toast(m);}});
        }).show());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);list.addView(card,lp);UiMotion.bindActions(card);
    }
    private void upload(Uri uri,String label){
        uploading=true;
        new Thread(()->{
            try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                if(in==null)throw new Exception();byte[] chunk=new byte[8192];int n,total=0;while((n=in.read(chunk))!=-1){total+=n;if(total>5*1024*1024)throw new IllegalArgumentException();out.write(chunk,0,n);}byte[] bytes=out.toByteArray();
                runOnUiThread(()->send(bytes,label));
            }catch(Exception e){runOnUiThread(()->{uploading=false;toast("Gagal membaca file atau ukuran melebihi 5 MB.");});}
        }).start();
    }
    private void send(byte[] bytes,String label){
        String token=SessionStore.get(this);if(token.isEmpty()){uploading=false;toast("Sesi berakhir. Masuk kembali.");return;}
        ProfileActivity.VolleyMultipartRequest req=new ProfileActivity.VolleyMultipartRequest(Request.Method.POST,ApiClient.BASE+"profile/certificates.php",response->{
            uploading=false;try{JSONObject json=new JSONObject(new String(response.data,StandardCharsets.UTF_8));toast(json.optString("message","Selesai"));if(json.optBoolean("success"))refresh();}catch(Exception e){toast("Respons server tidak valid.");}
        },error->{uploading=false;String msg="Unggahan gagal.";if(error.networkResponse!=null)try{msg=new JSONObject(new String(error.networkResponse.data,StandardCharsets.UTF_8)).optString("message",msg);}catch(Exception ignored){}toast(msg);}){
            @Override protected Map<String,String> getParams(){Map<String,String> p=new HashMap<>();p.put("action","upload");p.put("label",label);p.put("session_token",token);return p;}
            @Override protected Map<String,DataPart> getByteData(){Map<String,DataPart> f=new HashMap<>();f.put("certificate",new DataPart("certificate",bytes,"application/octet-stream"));return f;}
        };req.setRetryPolicy(new DefaultRetryPolicy(30000,0,1));Volley.newRequestQueue(getApplicationContext()).add(req);
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
