package com.example.lokerku;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;

/** Shared light surfaces for LokerKu-owned confirmation and form dialogs. */
public final class PremiumDialog {
    private PremiumDialog() { }
    public static final class Builder extends AlertDialog.Builder {
        private final Context source;
        public Builder(Context context) { super(context, R.style.LokerkuPremiumDialog); source = context; }
        @Override public AlertDialog show() {
            AlertDialog dialog = super.show();
            Window window = dialog.getWindow();
            if (window != null) {
                window.setWindowAnimations(R.style.LokerkuPremiumDialogAnimation);
                View decor = window.getDecorView();
                styleFields(decor, source);
                FontEnforcer.apply(decor, source);
            }
            styleButton(dialog.getButton(AlertDialog.BUTTON_NEGATIVE), false, source);
            styleButton(dialog.getButton(AlertDialog.BUTTON_NEUTRAL), false, source);
            styleButton(dialog.getButton(AlertDialog.BUTTON_POSITIVE), true, source);
            arrangeButtons(dialog, source);
            if (window != null) window.setLayout(Math.min(source.getResources().getDisplayMetrics().widthPixels - dp(source, 32), dp(source, 440)), ViewGroup.LayoutParams.WRAP_CONTENT);
            return dialog;
        }
    }
    private static int dp(Context c, float v) { return (int)(v * c.getResources().getDisplayMetrics().density + .5f); }
    private static GradientDrawable rounded(Context c, int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(c, radius));
        if (stroke != 0) d.setStroke(dp(c, 1), stroke);
        return d;
    }
    private static void styleFields(View view, Context c) {
        if (view instanceof EditText) {
            EditText field = (EditText)view;
            field.setTextColor(0xff18213d); field.setHintTextColor(0xff78839b);
            field.setBackgroundTintList(null);
            field.setBackground(rounded(c, 0xfff5f7ff, 14, 0xffdce3fa));
            field.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
            field.setMinHeight(dp(c, 52));
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)view;
            for (int i=0; i<group.getChildCount(); i++) styleFields(group.getChildAt(i), c);
        }
    }
    private static void arrangeButtons(AlertDialog dialog, Context c) {
        Button positive=dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        Button negative=dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button neutral=dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        Button first=positive != null && positive.getParent() != null ? positive : negative;
        if (first == null || !(first.getParent() instanceof ViewGroup)) return;
        ViewGroup old=(ViewGroup) first.getParent();
        if (!(old.getParent() instanceof ViewGroup)) return;
        ViewGroup host=(ViewGroup) old.getParent(); int index=host.indexOfChild(old);
        ViewGroup.LayoutParams existing=old.getLayoutParams();
        LinearLayout column=new LinearLayout(c); column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(c,20),dp(c,8),dp(c,20),dp(c,20));
        Button[] order={positive,neutral,negative};
        for (Button b:order) if (b!=null && b.getVisibility()==View.VISIBLE) {
            if (b.getParent() instanceof ViewGroup) ((ViewGroup)b.getParent()).removeView(b);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(c,8);
            column.addView(b,lp);
        }
        host.removeViewAt(index); host.addView(column,index,existing);
    }
    private static void styleButton(Button button, boolean primary, Context c) {
        if (button == null) return;
        button.setAllCaps(false); button.setSingleLine(false); button.setMaxLines(2); button.setLetterSpacing(0f); button.setTextColor(primary ? Color.WHITE : 0xff313dd1);
        button.setTypeface(AppFont.semibold(c)); button.setTextSize(13);
        button.setMinHeight(dp(c, 48)); button.setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8));
        button.setBackgroundTintList(null); button.setElevation(0); button.setStateListAnimator(null);
        GradientDrawable bg = rounded(c, primary ? 0xff303deb : 0xffeef1ff, 14, 0);
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(primary ? 0x33ffffff : 0x22303deb), bg, null));
        UiMotion.bindPress(button);
    }
}
