package com.example.lokerku;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;

/** Translucent layered surface. Not a real-time background blur. */
final class AuthGlass {
    private AuthGlass() { }
    static GradientDrawable card(Context c) {
        float d=c.getResources().getDisplayMetrics().density;
        GradientDrawable glass=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xb44b2b69,0xc43f255d,0xce352052});
        glass.setCornerRadius(28*d);glass.setStroke(Math.max(1,Math.round(d)),0x99e6f3ff);return glass;
    }
    static GradientDrawable field(Context c, boolean focused) {
        float d=c.getResources().getDisplayMetrics().density;
        GradientDrawable glass=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x745e3b79,0x88452d60});
        glass.setCornerRadius(14*d);glass.setStroke(Math.max(1,Math.round((focused?2:1)*d)),focused?0xffd4eeff:0x99c6dcff);return glass;
    }
}
