package com.example.lokerku;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.Locale;

public class JobDetailActivity extends AppCompatActivity {

    private static final int NAVY = Color.rgb(21, 26, 61);
    private static final int TEAL = Color.rgb(0, 0, 255);
    private static final int BG = Color.rgb(247, 248, 255);
    private static final int TEXT = Color.rgb(21, 26, 61);
    private static final int MUTED = Color.rgb(104, 112, 143);
    private static final int WHITE = Color.WHITE;

    private JSONObject job;

    private TextView tvTitle;
    private TextView tvCompany;
    private TextView tvLocation;
    private TextView tvCategory;
    private TextView tvType;
    private TextView tvSalary;
    private TextView tvDescription;
    private TextView tvRequirements;
    private TextView tvAddress;
    private Button btnMap;

    private Button btnApply;
    private Button btnFavorite;

    private int jobId = -1;
    private boolean isFavorite = false;
    private static final String PREF_FAVORITES = "lokerku_favorites";
    private static final String KEY_FAVORITES = "job_ids";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String jobJson = getIntent().getStringExtra("job_json");

        if (jobJson == null || jobJson.trim().isEmpty()) {
            Toast.makeText(
                    this,
                    "Data pekerjaan tidak ditemukan.",
                    Toast.LENGTH_LONG
            ).show();

            finish();
            return;
        }

        try {
            job = new JSONObject(jobJson);
            jobId = job.optInt("id", -1);
        } catch (JSONException e) {
            Toast.makeText(
                    this,
                    "Data pekerjaan tidak valid.",
                    Toast.LENGTH_LONG
            ).show();

            finish();
            return;
        }

        buatTampilan();
        tampilkanDataPekerjaan();
    }

    private void buatTampilan() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(BG);
        scrollView.setClipToPadding(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setClipChildren(false);
        root.setClipToPadding(false);

        scrollView.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(16), dp(20), dp(28));
        header.setBackground(buatGradient(
                NAVY,
                Color.rgb(0, 0, 204),
                dp(24)
        ));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);

        TextView btnBack = new TextView(this);
        btnBack.setText("‹");
        btnBack.setTextSize(38);
        btnBack.setTextColor(WHITE);
        btnBack.setGravity(Gravity.CENTER);
        btnBack.setContentDescription("Kembali");
        btnBack.setBackground(buatBackground(
                Color.argb(35, 255, 255, 255),
                dp(14)
        ));

        LinearLayout.LayoutParams backParams =
                new LinearLayout.LayoutParams(dp(46), dp(46));

        topBar.addView(btnBack, backParams);

        TextView tvHeader = new TextView(this);
        tvHeader.setText("Detail Pekerjaan");
        tvHeader.setTextColor(WHITE);
        tvHeader.setTextSize(18);
        tvHeader.setTypeface(AppFont.semibold(this));
        tvHeader.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams headerTitleParams =
                new LinearLayout.LayoutParams(
                        0,
                        dp(46),
                        1
                );

        headerTitleParams.leftMargin = dp(12);
        topBar.addView(tvHeader, headerTitleParams);

        TextView spacer = new TextView(this);
        topBar.addView(
                spacer,
                new LinearLayout.LayoutParams(dp(46), dp(46))
        );

        btnBack.setOnClickListener(v -> finish());

        header.addView(topBar);

        TextView tvHeaderCaption = new TextView(this);
        tvHeaderCaption.setText("Temukan pekerjaan yang sesuai denganmu");
        tvHeaderCaption.setTextSize(13);
        tvHeaderCaption.setTextColor(Color.rgb(218, 231, 239));
        tvHeaderCaption.setPadding(0, dp(20), 0, 0);

        header.addView(tvHeaderCaption);
        root.addView(header);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(18), dp(18), dp(40));
        content.setClipChildren(false);
        content.setClipToPadding(false);

        root.addView(content);

        LinearLayout jobCard = new LinearLayout(this);
        jobCard.setOrientation(LinearLayout.VERTICAL);
        jobCard.setPadding(dp(22), dp(24), dp(22), dp(24));
        jobCard.setBackground(buatBackground(WHITE, dp(26)));
        jobCard.setElevation(dp(3));

        content.addView(
                jobCard,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        TextView tvLabel = new TextView(this);
        tvLabel.setText("INFORMASI LOWONGAN");
        tvLabel.setTextSize(11);
        tvLabel.setLetterSpacing(0.08f);
        tvLabel.setTextColor(TEAL);
        tvLabel.setTypeface(AppFont.semibold(this));

        jobCard.addView(tvLabel);

        tvTitle = new TextView(this);
        tvTitle.setTextSize(24);
        tvTitle.setTextColor(NAVY);
        tvTitle.setTypeface(AppFont.semibold(this));
        tvTitle.setPadding(0, dp(14), 0, dp(8));

        jobCard.addView(tvTitle);

        tvCompany = new TextView(this);
        tvCompany.setTextSize(15);
        tvCompany.setTextColor(TEXT);
        tvCompany.setTypeface(AppFont.semibold(this));

        jobCard.addView(tvCompany);

        tvLocation = buatTextView(14, MUTED);
        tvLocation.setPadding(0, dp(8), 0, 0);
        jobCard.addView(tvLocation);

        LinearLayout tags = new LinearLayout(this);
        tags.setOrientation(LinearLayout.HORIZONTAL);
        tags.setGravity(Gravity.CENTER_VERTICAL);
        tags.setPadding(0, dp(18), 0, 0);

        tvCategory = buatTag();
        tvType = buatTag();

        LinearLayout.LayoutParams tagParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        tagParams.rightMargin = dp(8);

        tags.addView(tvCategory, tagParams);
        tags.addView(tvType);

        android.widget.HorizontalScrollView tagScroll = new android.widget.HorizontalScrollView(this);
        tagScroll.setHorizontalScrollBarEnabled(false);
        tagScroll.addView(tags);
        jobCard.addView(tagScroll);

        TextView salaryLabel = buatSectionTitle("Kisaran Gaji");
        salaryLabel.setPadding(0, dp(24), 0, dp(8));
        jobCard.addView(salaryLabel);

        tvSalary = buatTextView(17, TEAL);
        tvSalary.setTypeface(AppFont.semibold(this));
        jobCard.addView(tvSalary);

        LinearLayout descriptionCard = buatSectionCard(content);

        TextView descriptionTitle = buatSectionTitle("Deskripsi Pekerjaan");
        descriptionCard.addView(descriptionTitle);

        tvDescription = buatTextView(14, TEXT);
        tvDescription.setPadding(0, dp(12), 0, 0);
        tvDescription.setLineSpacing(dp(4), 1.0f);
        descriptionCard.addView(tvDescription);

        LinearLayout requirementCard = buatSectionCard(content);

        TextView requirementTitle = buatSectionTitle("Persyaratan");
        requirementCard.addView(requirementTitle);

        tvRequirements = buatTextView(14, TEXT);
        tvRequirements.setPadding(0, dp(12), 0, 0);
        tvRequirements.setLineSpacing(dp(4), 1.0f);
        requirementCard.addView(tvRequirements);

        LinearLayout locationCard = buatSectionCard(content);
        locationCard.addView(buatSectionTitle("Alamat & Lokasi"));

        tvAddress = buatTextView(14, TEXT);
        tvAddress.setPadding(0, dp(12), 0, dp(14));
        tvAddress.setLineSpacing(dp(3), 1.0f);
        locationCard.addView(tvAddress);

        btnMap = new Button(this);
        btnMap.setText("Lihat lokasi di Google Maps");
        btnMap.setTextColor(WHITE);
        btnMap.setTextSize(14);
        btnMap.setAllCaps(false);
        btnMap.setTypeface(AppFont.semibold(this));
        btnMap.setBackground(buatBackground(TEAL, dp(16)));
        btnMap.setMinHeight(dp(48));
        locationCard.addView(btnMap, new LinearLayout.LayoutParams(-1, -2));
        btnMap.setOnClickListener(v -> bukaGoogleMaps());

        LinearLayout actionCard = new LinearLayout(this);
        actionCard.setOrientation(LinearLayout.VERTICAL);
        actionCard.setPadding(dp(20), dp(20), dp(20), dp(20));
        GradientDrawable actionSurface = buatBackground(WHITE, dp(24));
        actionSurface.setStroke(dp(1), Color.rgb(221, 224, 255));
        actionCard.setBackground(actionSurface);
        actionCard.setElevation(dp(3));

        LinearLayout.LayoutParams actionParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        actionParams.topMargin = dp(16);
        content.addView(actionCard, actionParams);

        TextView actionsHeading = buatSectionTitle("Langkah berikutnya");
        actionCard.addView(actionsHeading);
        TextView actionsHint = buatTextView(12, MUTED);
        actionsHint.setText("Simpan lowongan pilihanmu agar mudah ditemukan kembali.");
        actionsHint.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(-1, -2);
        hintParams.topMargin = dp(6); hintParams.bottomMargin = dp(16);
        actionCard.addView(actionsHint, hintParams);

        btnApply = new Button(this);
        btnApply.setText("Catat Lamaran");
        btnApply.setTextColor(WHITE);
        btnApply.setTextSize(15);
        btnApply.setAllCaps(false);
        btnApply.setBackgroundTintList(null);
        btnApply.setElevation(0);
        btnApply.setStateListAnimator(null);
        btnApply.setTypeface(AppFont.semibold(this));
        btnApply.setBackground(buatGradient(Color.rgb(0, 0, 204), Color.rgb(62, 68, 255), dp(16)));
        btnApply.setMinHeight(dp(54));

        actionCard.addView(
                btnApply,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );
        TextView applyStatus = buatTextView(11, MUTED);
        applyStatus.setText("Dicatat di Pijar Karier, tidak dikirim otomatis ke perusahaan.");
        applyStatus.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams asp = new LinearLayout.LayoutParams(-1, -2); asp.topMargin = dp(7);
        actionCard.addView(applyStatus, asp);

        btnFavorite = new Button(this);
        btnFavorite.setText("Simpan Lowongan");
        btnFavorite.setTextColor(NAVY);
        btnFavorite.setTextSize(14);
        btnFavorite.setAllCaps(false);
        btnFavorite.setElevation(0);
        btnFavorite.setStateListAnimator(null);
        btnFavorite.setTypeface(AppFont.semibold(this));
        btnFavorite.setBackground(buatBackground(
                Color.rgb(232, 232, 255),
                dp(14)
        ));

        LinearLayout.LayoutParams favoriteParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
        btnFavorite.setMinHeight(dp(54));

        favoriteParams.topMargin = dp(10);

        actionCard.addView(btnFavorite, favoriteParams);

        btnApply.setOnClickListener(v -> new PremiumDialog.Builder(this)
                .setTitle("Catat lamaran ini?")
                .setMessage("Lamaran akan tercatat di Pijar Karier untuk pemantauan. Data ini tidak otomatis dikirim ke perusahaan.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Catat", (dialog, which) -> {
                    if(jobId <= 0) { Toast.makeText(this,"Lowongan tidak valid.",Toast.LENGTH_LONG).show(); return; }
                    btnApply.setEnabled(false);
                    java.util.Map<String,String> p=new java.util.HashMap<>();p.put("action","create");p.put("job_id",String.valueOf(jobId));
                    ApiClient.post(this,"profile/applications.php",p,new ApiClient.Result() {
                        public void success(JSONObject json) {btnApply.setEnabled(true);Toast.makeText(JobDetailActivity.this,json.optString("message","Tercatat"),Toast.LENGTH_LONG).show();}
                        public void fail(String message) {btnApply.setEnabled(true);Toast.makeText(JobDetailActivity.this,message,Toast.LENGTH_LONG).show();}
                    });
                }).show());

        isFavorite = isJobFavorite();
        updateFavoriteButton();
        btnFavorite.setOnClickListener(v -> {
            isFavorite = !isFavorite;
            simpanStatusFavorit();
            updateFavoriteButton();
            Toast.makeText(
                    JobDetailActivity.this,
                    isFavorite ? "Lowongan disimpan ke favorit" : "Lowongan dihapus dari favorit",
                    Toast.LENGTH_SHORT
            ).show();
        });

        setContentView(scrollView);
        FontEnforcer.apply(scrollView, this);
        UiMotion.styleButtons(scrollView);
        UiMotion.bindActions(scrollView);
        UiMotion.bindPress(btnBack);
        UiMotion.reveal(header, 40);
        UiMotion.revealChildren(content, 120, 80, 7);
    }

    @Override protected void onPause() {
        UiMotion.finishReveals(getWindow().getDecorView());
        super.onPause();
    }

    private void tampilkanDataPekerjaan() {
        String title = ambilString(
                "judul",
                "title",
                "nama_pekerjaan"
        );

        String company = ambilString(
                "perusahaan",
                "company",
                "nama_perusahaan"
        );

        String location = ambilString(
                "lokasi",
                "location",
                "kota"
        );

        String category = ambilString(
                "kategori_nama",
                "kategori",
                "category"
        );

        String type = ambilString(
                "tipe",
                "jenis_pekerjaan",
                "type"
        );

        String description = ambilString(
                "deskripsi",
                "description"
        );

        String requirements = ambilString(
                "persyaratan",
                "requirements",
                "kualifikasi"
        );

        int salaryMin = ambilAngka(
                "gaji_min",
                "salary_min",
                "gaji_minimum"
        );

        int salaryMax = ambilAngka(
                "gaji_max",
                "salary_max",
                "gaji_maksimum"
        );

        tvTitle.setText(title);
        tvCompany.setText(company);
        tvLocation.setText("⌖  " + location);
        String address = ambilString(
                "alamat_lengkap", "alamat", "full_address",
                "address", "alamat_perusahaan", "address_company"
        );
        if ("Informasi belum tersedia.".equals(address)) {
            address = location;
        }
        tvAddress.setText(address);
        tvCategory.setText(category);
        tvType.setText(type);
        tvDescription.setText(description);
        tvRequirements.setText(requirements);
        tvSalary.setText(formatGaji(salaryMin, salaryMax));
    }

    private boolean isCoordinate(String value) {
        if (value == null || value.trim().isEmpty()
                || "Informasi belum tersedia.".equals(value)) return false;
        try {
            Double.parseDouble(value.trim());
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    private boolean isJobFavorite() {
        if (jobId < 0) return false;
        SharedPreferences prefs = getSharedPreferences(FavoritesStore.name(this), MODE_PRIVATE);
        java.util.Set<String> saved = prefs.getStringSet(KEY_FAVORITES, new java.util.HashSet<>());
        return saved != null && saved.contains(String.valueOf(jobId));
    }

    private void simpanStatusFavorit() {
        if (jobId < 0) return;
        SharedPreferences prefs = getSharedPreferences(FavoritesStore.name(this), MODE_PRIVATE);
        java.util.Set<String> current = prefs.getStringSet(KEY_FAVORITES, new java.util.HashSet<>());
        java.util.Set<String> saved = current == null
                ? new java.util.HashSet<>() : new java.util.HashSet<>(current);
        String id = String.valueOf(jobId);
        if (isFavorite) saved.add(id); else saved.remove(id);
        prefs.edit().putStringSet(KEY_FAVORITES, saved).apply();
    }

    private void updateFavoriteButton() {
        if (btnFavorite == null) return;
        String label = isFavorite ? "Tersimpan di Favorit" : "Simpan ke Favorit";
        btnFavorite.setTextColor(isFavorite ? TEAL : NAVY);
        btnFavorite.setContentDescription(label);
        btnFavorite.setGravity(Gravity.CENTER);
        btnFavorite.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        android.text.SpannableString caption = new android.text.SpannableString("\uFFFC  " + label);
        android.graphics.drawable.Drawable heartIcon = getDrawable(R.drawable.ic_favorite);
        if (heartIcon != null) {
            heartIcon = heartIcon.mutate();
            heartIcon.setTint(isFavorite ? TEAL : NAVY);
            heartIcon.setBounds(0, 0, dp(20), dp(20));
            caption.setSpan(new android.text.style.ImageSpan(heartIcon, android.text.style.ImageSpan.ALIGN_BOTTOM), 0, 1, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        btnFavorite.setText(caption);
        GradientDrawable state = buatBackground(
                isFavorite ? Color.rgb(232, 232, 255) : Color.WHITE, dp(16));
        state.setStroke(dp(1), isFavorite ? Color.rgb(110, 120, 255) : Color.rgb(207, 216, 247));
        btnFavorite.setBackgroundTintList(null);
        btnFavorite.setBackground(new android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x330000ff), state, null));
        btnFavorite.setMinHeight(dp(50));
    }

    private void bukaGoogleMaps() {
        String address = tvAddress == null ? "" : tvAddress.getText().toString().trim();
        String company = ambilString("perusahaan", "company", "nama_perusahaan");
        String query = address;
        if (query.isEmpty() || "Informasi belum tersedia.".equals(query)) {
            query = ambilString("lokasi", "location", "kota");
        }
        if (!company.isEmpty() && !query.toLowerCase(Locale.ROOT).contains(company.toLowerCase(Locale.ROOT))) {
            query = query + " " + company;
        }
        if (query.trim().isEmpty() || "Lokasi tidak dicantumkan".equals(query)) {
            Toast.makeText(this, "Alamat lowongan belum tersedia dari server.", Toast.LENGTH_LONG).show();
            return;
        }
        String latitude = ambilString("latitude", "lat", "koordinat_latitude");
        String longitude = ambilString("longitude", "lng", "lon", "koordinat_longitude");
        String mapQuery = query;
        if (isCoordinate(latitude) && isCoordinate(longitude)) {
            mapQuery = latitude + "," + longitude;
        }
        Uri mapsUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(mapQuery));
        Intent mapsIntent = new Intent(Intent.ACTION_VIEW, mapsUri);
        try {
            startActivity(mapsIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak dapat membuka Google Maps.", Toast.LENGTH_LONG).show();
        }
    }

    private String ambilString(String... keys) {
        for (String key : keys) {
            if (job.has(key) && !job.isNull(key)) {
                String value = job.optString(key, "").trim();

                if (!value.isEmpty()
                        && !"null".equalsIgnoreCase(value)) {
                    return value;
                }
            }
        }

        if (keys.length > 0) {
            if ("judul".equals(keys[0])
                    || "title".equals(keys[0])
                    || "nama_pekerjaan".equals(keys[0])) {
                return "Lowongan Pekerjaan";
            }

            if ("perusahaan".equals(keys[0])
                    || "company".equals(keys[0])
                    || "nama_perusahaan".equals(keys[0])) {
                return "Nama perusahaan tidak tersedia";
            }

            if ("lokasi".equals(keys[0])
                    || "location".equals(keys[0])
                    || "kota".equals(keys[0])) {
                return "Lokasi tidak dicantumkan";
            }

            if ("tipe".equals(keys[0])
                    || "jenis_pekerjaan".equals(keys[0])
                    || "type".equals(keys[0])) {
                return "Tipe tidak dicantumkan";
            }

            if ("kategori_nama".equals(keys[0])
                    || "kategori".equals(keys[0])
                    || "category".equals(keys[0])) {
                return "Umum";
            }
        }

        return "Informasi belum tersedia.";
    }

    private int ambilAngka(String... keys) {
        for (String key : keys) {
            if (!job.has(key) || job.isNull(key)) {
                continue;
            }

            Object value = job.opt(key);

            if (value instanceof Number) {
                return ((Number) value).intValue();
            }

            if (value instanceof String) {
                try {
                    return Integer.parseInt(
                            ((String) value).trim()
                    );
                } catch (NumberFormatException ignored) {
                    // Coba nama kolom berikutnya.
                }
            }
        }

        return 0;
    }

    private String formatGaji(int minimum, int maksimum) {
        if (minimum <= 0 && maksimum <= 0) {
            return "Gaji tidak dicantumkan";
        }

        NumberFormat formatter = NumberFormat.getNumberInstance(
                new Locale("id", "ID")
        );

        if (minimum > 0 && maksimum > 0) {
            return "Rp " + formatter.format(minimum)
                    + " – Rp " + formatter.format(maksimum);
        }

        if (minimum > 0) {
            return "Mulai Rp " + formatter.format(minimum);
        }

        return "Hingga Rp " + formatter.format(maksimum);
    }

    private LinearLayout buatSectionCard(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackground(buatBackground(WHITE, dp(24)));
        card.setElevation(dp(2));

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.topMargin = dp(16);

        parent.addView(card, params);

        return card;
    }

    private TextView buatSectionTitle(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(17);
        view.setTextColor(NAVY);
        view.setTypeface(AppFont.semibold(this));

        return view;
    }

    private TextView buatTextView(int size, int color) {
        TextView view = new TextView(this);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.START);
        view.setIncludeFontPadding(true);

        return view;
    }

    private TextView buatTag() {
        TextView view = new TextView(this);
        view.setTextSize(12);
        view.setTextColor(TEAL);
        view.setPadding(dp(12), dp(8), dp(12), dp(8));
        view.setBackground(buatBackground(
                Color.rgb(232, 232, 255),
                dp(10)
        ));

        return view;
    }

    private GradientDrawable buatBackground(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        if (color == WHITE) drawable.setStroke(dp(1), Color.rgb(221, 224, 255));
        drawable.setCornerRadius(radius);

        return drawable;
    }

    private GradientDrawable buatGradient(
            int startColor,
            int endColor,
            int radius
    ) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{startColor, endColor}
        );

        drawable.setCornerRadius(radius);

        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources()
                .getDisplayMetrics().density + 0.5f);
    }
}
