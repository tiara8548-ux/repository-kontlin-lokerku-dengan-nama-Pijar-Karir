package com.example.lokerku;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ViewFlipper;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String API_JOBS =
            "https://ahannaja.cu.ma/lokerku_api/jobs/list.php";

    private static final String PREF_USER = "lokerku_user";
    private static final String PREF_FAVORITES = "lokerku_favorites";
    private static final String KEY_FAVORITES = "job_ids";

    private static final int BLUE = PijarStyle.PURPLE;
    private static final int BLUE_DARK = PijarStyle.PURPLE_DARK;
    private static final int BLUE_LIGHT = PijarStyle.LAVENDER;
    private static final int BACKGROUND = PijarStyle.CREAM;
    private static final int WHITE = Color.WHITE;
    private static final int TEXT = PijarStyle.INK;
    private static final int MUTED = PijarStyle.MUTED;
    private static final int BORDER = 0xffeadfea;
    private static final int RED = Color.rgb(220, 65, 80);
    private static final int GREEN = Color.rgb(28, 150, 100);

    private LinearLayout root;
    private LinearLayout content;
    private ScrollView mainScroll;
    private LinearLayout bottomNavigation;
    private final LinearLayout[] navItems = new LinearLayout[5];
    private final ImageView[] navIcons = new ImageView[5];
    private final TextView[] navLabels = new TextView[5];
    private String lastNavPage;
    private boolean pageRendered;
    private EditText searchInput;
    private LinearLayout searchContainer;
    private LinearLayout sharedHeader;
    private TextView headerEyebrow, headerTitle, headerSubtitle;

    private SharedPreferences userPrefs;
    private SharedPreferences favoritePrefs;

    private final List<JSONObject> jobs = new ArrayList<>();
    private final Set<String> favorites = new HashSet<>();

    private String username = "Pengguna";
    private String email = "";
    private String phone = "";

    private String currentPage = "Beranda";
    private String selectedCategory = "Semua";
    private String searchQuery = "";

    private boolean isLoading = false;
    private boolean ignoreSearchChange = false;

    private final Handler bannerHandler = new Handler(Looper.getMainLooper());
    private Runnable bannerRunnable;
    private ViewFlipper bannerFlipper;
    private float bannerTouchDownX;
    private float bannerTouchDownY;
    private LinearLayout bannerIndicators;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        userPrefs = getSharedPreferences(
                PREF_USER, MODE_PRIVATE
        );

        favoritePrefs = getSharedPreferences(
                FavoritesStore.name(this), MODE_PRIVATE
        );

        Set<String> saved = favoritePrefs.getStringSet(
                KEY_FAVORITES, new HashSet<>()
        );

        if (saved != null) {
            favorites.addAll(saved);
        }

        String intentName = getIntent().getStringExtra("username");

        username = userPrefs.getString(
                "username",
                intentName == null || intentName.trim().isEmpty()
                        ? userPrefs.getString("nama", "Pengguna")
                        : intentName
        );

        if (username == null || username.trim().isEmpty()) username = userPrefs.getString("nama", "Pengguna");
        email = userPrefs.getString("email", "");

        phone = userPrefs.getString(
                "phone",
                userPrefs.getString("no_hp", "")
        );

        selectedCategory = userPrefs.getString(
                "category", "Semua"
        );

        buildScreen();
        loadJobs();
    }

    private void buildScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BACKGROUND);

        ScrollView scrollView = new ScrollView(this);
        mainScroll = scrollView;
        scrollView.setFillViewport(false);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setClipToPadding(false);
        // The dock has its own area so it cannot cover the scrolling content.
        scrollView.setPadding(0, 0, 0, dp(12));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);

        scrollView.addView(
                page,
                new ScrollView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        buildHeader(page);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(
                dp(18), dp(18), dp(18), dp(24)
        );

        page.addView(
                content,
                new LinearLayout.LayoutParams(
                        -1, -2
                )
        );

        root.addView(
                scrollView,
                new LinearLayout.LayoutParams(
                        -1, 0, 1
                )
        );

        bottomNavigation = new LinearLayout(this);
        bottomNavigation.setOrientation(
                LinearLayout.HORIZONTAL
        );
        bottomNavigation.setGravity(Gravity.CENTER);
        bottomNavigation.setPadding(
                dp(7), dp(7), dp(7), dp(7)
        );
        bottomNavigation.setBackground(
                rounded(WHITE, 22)
        );
        bottomNavigation.setElevation(dp(9));

        LinearLayout.LayoutParams navParams = new LinearLayout.LayoutParams(-1, -2);
        navParams.setMargins(dp(12), dp(4), dp(12), dp(10));
        root.addView(bottomNavigation, navParams);
        setContentView(root);

        renderPage("Beranda");
    }

    private void buildHeader(LinearLayout parent) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        sharedHeader = header;
        header.setPadding(
                dp(22), dp(26), dp(22), dp(24)
        );
        header.setBackground(
                gradient(BLUE_DARK, BLUE)
        );

        LinearLayout top = row();

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);

        headerEyebrow = text("PIJAR KARIER  /  CAREER SPACE", 10, 0xffdce2ff, true);
        headerTitle = text("Temukan karier terbaikmu", 21, WHITE, true);
        brand.addView(headerEyebrow);
        brand.addView(headerTitle);

        top.addView(
                brand,
                new LinearLayout.LayoutParams(0, -2, 1)
        );

        FrameLayout notification = new FrameLayout(this);
        notification.setBackground(
                rounded(0xff8959bd, 15)
        );
        notification.setClickable(true);
        notification.setFocusable(true);
        notification.setContentDescription("Notifikasi");

        ImageView notificationIcon = new ImageView(this);
        notificationIcon.setImageResource(R.drawable.ic_notifications);
        notificationIcon.setColorFilter(WHITE);
        notificationIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams notificationIconParams =
                new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER);
        notification.addView(notificationIcon, notificationIconParams);

        top.addView(
                notification,
                new LinearLayout.LayoutParams(dp(44), dp(44))
        );

        notification.setOnClickListener(v -> showNotificationsDialog());

        header.addView(top);

        TextView subtitle = text(
                "Peluang baru dimulai dari sini.",
                12, Color.rgb(226, 230, 255), false
        );

        headerSubtitle = subtitle;
        LinearLayout.LayoutParams subParams =
                new LinearLayout.LayoutParams(-1, -2);

        subParams.topMargin = dp(6);
        header.addView(subtitle, subParams);

        searchContainer = row();
        searchContainer.setGravity(Gravity.CENTER_VERTICAL);
        searchContainer.setPadding(
                dp(13), 0, dp(13), 0
        );
        searchContainer.setBackground(rounded(WHITE, 15));

        TextView searchIcon = text(
                "⌕", 26, BLUE, true
        );

        searchContainer.addView(
                searchIcon,
                new LinearLayout.LayoutParams(
                        dp(30), dp(48)
                )
        );

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(13);
        searchInput.setTextColor(TEXT);
        searchInput.setHintTextColor(MUTED);
        searchInput.setHint(
                "Cari posisi, perusahaan, atau lokasi"
        );
        searchInput.setPadding(
                dp(5), 0, dp(4), 0
        );
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        searchInput.setTypeface(AppFont.regular(this));
        searchInput.setSelectAllOnFocus(false);

        searchContainer.addView(
                searchInput,
                new LinearLayout.LayoutParams(0, dp(49), 1)
        );

        LinearLayout.LayoutParams searchParams =
                new LinearLayout.LayoutParams(-1, dp(49));

        searchParams.topMargin = dp(17);
        header.addView(searchContainer, searchParams);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence s, int start,
                    int count, int after
            ) {}

            @Override
            public void onTextChanged(
                    CharSequence s, int start,
                    int before, int count
            ) {
                if (ignoreSearchChange) return;

                searchQuery = s.toString().trim();

                if (currentPage.equals("Beranda")
                        || currentPage.equals("Eksplorasi")) {
                    renderPage(currentPage);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        parent.addView(header);
    }

    private void renderPage(String page) {
        String previousPage = currentPage;
        boolean pageChanged = previousPage != null && !previousPage.equals(page);
        currentPage = page;
        if (!"Beranda".equals(page)) {
            stopBannerAutoSlide();
        }

        if (content == null) return;

        UiMotion.finishReveals(content);
        content.removeAllViews();
        buildBottomNavigation();
        updatePageHeader(page);

        boolean showSearch =
                page.equals("Beranda")
                        || page.equals("Eksplorasi");

        // Sembunyikan seluruh wadah pencarian di halaman Favorit, Lamaran, dan Profil.
        // Ini mencegah kotak putih kosong tertinggal di header.
        if (searchContainer != null) {
            searchContainer.setVisibility(
                    showSearch ? View.VISIBLE : View.GONE
            );
        }

        switch (page) {
            case "Beranda":
                homePage();
                break;

            case "Eksplorasi":
                explorePage();
                break;

            case "Favorit":
                favoritePage();
                break;

            case "Lamaran":
                applicationPage();
                break;

            case "Profil":
                profilePage();
                break;

            default:
                homePage();
                break;
        }
        FontEnforcer.apply(root, this);

        if (pageChanged && mainScroll != null) mainScroll.post(() -> mainScroll.scrollTo(0, 0));
        UiMotion.styleButtons(content);
        UiMotion.bindActions(content);
        if (pageChanged || !pageRendered) {
            UiMotion.revealChildren(content, 70, 65, 9);
        }
        pageRendered = true;
    }

    private void updatePageHeader(String page) {
        if (sharedHeader == null) return;
        if ("Profil".equals(page)) { sharedHeader.setVisibility(View.GONE); return; }
        sharedHeader.setVisibility(View.VISIBLE);
        int a = PijarStyle.PURPLE_DARK, b = 0xff9a4c93;
        String label = "CAREER SPACE", title = "Temukan karier terbaikmu", subtitle = "Peluang baru dimulai dari sini.";
        if ("Eksplorasi".equals(page)) {
            label = "TEMUKAN PELUANG"; title = "Jelajahi pekerjaan";
            subtitle = "Temukan posisi yang sesuai dengan tujuanmu."; a = 0xff49307c; b = 0xffa05298;
        } else if ("Favorit".equals(page)) {
            label = "PILIHANMU"; title = "Peluang tersimpan";
            subtitle = "Semua lowongan pilihan dalam satu tempat."; a = 0xff6a286e; b = 0xffaa5385;
        } else if ("Lamaran".equals(page)) {
            label = "PERJALANAN KARIER"; title = "Langkah berikutnya";
            subtitle = "Pantau dan persiapkan perjalanan kariermu."; a = 0xff46327f; b = 0xff7761af;
        }
        sharedHeader.setBackground(gradient(a, b));
        headerEyebrow.setText("PIJAR KARIER  /  " + label);
        headerTitle.setText(title);
        headerSubtitle.setText(subtitle);
    }

    private int pageIndex(String page) {
        if ("Beranda".equals(page)) return 0;
        if ("Eksplorasi".equals(page)) return 1;
        if ("Favorit".equals(page)) return 2;
        if ("Lamaran".equals(page)) return 3;
        if ("Profil".equals(page)) return 4;
        return 0;
    }

    private void buildBottomNavigation() {
        String[] labels = {"Beranda", "Eksplorasi", "Favorit", "Lamaran", "Profil"};
        int[] icons = {R.drawable.ic_home, R.drawable.ic_search, R.drawable.ic_favorite,
                R.drawable.ic_work, R.drawable.ic_person};
        if (navItems[0] == null) {
            bottomNavigation.setGravity(Gravity.CENTER);
            bottomNavigation.setOrientation(LinearLayout.HORIZONTAL);
            bottomNavigation.setPadding(dp(7), dp(7), dp(7), dp(7));
            GradientDrawable dock = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{0xfffff5f7, 0xfffff5f7, 0xfffff5f7});
            dock.setCornerRadius(dp(28));
            dock.setStroke(dp(1), 0xffeddde9);
            GradientDrawable reflection = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0x00ffffff,0x00ffffff});
            reflection.setCornerRadius(dp(26));
            android.graphics.drawable.LayerDrawable dockGlass = new android.graphics.drawable.LayerDrawable(
                    new android.graphics.drawable.Drawable[]{dock, reflection});
            dockGlass.setLayerInset(1,dp(2),dp(2),dp(2),dp(32));
            bottomNavigation.setBackground(dockGlass);
            bottomNavigation.setElevation(dp(10));
            for (int i = 0; i < labels.length; i++) {
                final String label = labels[i];
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.HORIZONTAL);
                item.setGravity(Gravity.CENTER);
                item.setMinimumHeight(dp(52));
                item.setPadding(dp(3), dp(8), dp(3), dp(8));
                item.setClickable(true);
                item.setFocusable(true);
                ImageView icon = new ImageView(this);
                icon.setImageResource(icons[i]);
                icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
                item.addView(icon, new LinearLayout.LayoutParams(dp(24), dp(24)));
                TextView title = text(label, 11, BLUE, true);
                title.setSingleLine(true);
                title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                title.setIncludeFontPadding(false);
                title.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-2, -2);
                titleParams.leftMargin = dp(6);
                item.addView(title, titleParams);
                item.setOnClickListener(v -> { if (!currentPage.equals(label)) renderPage(label); });
                UiMotion.bindPress(item);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -2, 1);
                params.setMargins(dp(1), 0, dp(1), 0);
                bottomNavigation.addView(item, params);
                navItems[i] = item;
                navIcons[i] = icon;
                navLabels[i] = title;
            }
        }
        boolean changed = lastNavPage != null && !lastNavPage.equals(currentPage);
        if (changed && bottomNavigation.isLaidOut()) {
            android.transition.TransitionSet transition = new android.transition.TransitionSet();
            transition.addTransition(new android.transition.ChangeBounds());
            transition.addTransition(new android.transition.Fade());
            transition.setDuration(220);
            transition.setInterpolator(new android.view.animation.PathInterpolator(.22f, .75f, .25f, 1f));
            android.transition.TransitionManager.beginDelayedTransition(bottomNavigation, transition);
        }
        for (int i = 0; i < labels.length; i++) {
            boolean active = currentPage.equals(labels[i]);
            LinearLayout item = navItems[i];
            item.setSelected(active);
            item.setContentDescription(labels[i] + (active ? ", halaman aktif" : ""));
            if (active) {
                // A single LokerKu blue is shared by all destinations.
                GradientDrawable glossy = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{PijarStyle.PURPLE_DARK, PijarStyle.PURPLE});
                glossy.setCornerRadius(dp(20)); glossy.setStroke(dp(1), 0x99ffffff);
                GradientDrawable sheen = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[]{0x55ffffff,0x08ffffff});
                sheen.setCornerRadius(dp(18));
                android.graphics.drawable.LayerDrawable glassDock = new android.graphics.drawable.LayerDrawable(
                        new android.graphics.drawable.Drawable[]{glossy,sheen});
                glassDock.setLayerInset(1,dp(2),dp(2),dp(2),dp(27));
                item.setBackground(glassDock); item.setElevation(dp(3));
            } else { item.setBackground(rounded(Color.TRANSPARENT, 20)); item.setElevation(0); }
            navIcons[i].setColorFilter(active ? WHITE : 0xff756b82);
            navLabels[i].setTextColor(WHITE);
            navLabels[i].setVisibility(active ? View.VISIBLE : View.GONE);
            if (changed && active) {
                android.animation.ObjectAnimator sx = android.animation.ObjectAnimator.ofFloat(navIcons[i], View.SCALE_X, .83f, 1.14f, 1f);
                android.animation.ObjectAnimator sy = android.animation.ObjectAnimator.ofFloat(navIcons[i], View.SCALE_Y, .83f, 1.14f, 1f);
                android.animation.AnimatorSet set = new android.animation.AnimatorSet();
                set.playTogether(sx, sy); set.setDuration(200); set.start();
            }
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) item.getLayoutParams();
            params.weight = active ? 2.15f : 1f;
            item.setLayoutParams(params);
        }
        lastNavPage = currentPage;
    }

    private void homePage() {
        addText("Halo, " + username, 23, TEXT, true);

        addText(
                "Siap untuk langkah berikutnya?",
                12, MUTED, false
        );

        addPijarHero();

        LinearLayout shortcuts = row();
        shortcuts.setGravity(Gravity.CENTER);
        shortcuts.setBaselineAligned(false);
        shortcuts.setClipChildren(false);
        shortcuts.setPadding(0, dp(2), 0, dp(2));

        shortcuts.addView(
                shortcut(
                        R.drawable.ic_search, "Cari kerja", "Jelajahi posisi",
                        () -> renderPage("Eksplorasi")
                ),
                shortcutCardLayoutParams()
        );

        shortcuts.addView(
                shortcut(
                        R.drawable.ic_favorite, "Favorit", "Tersimpan",
                        () -> renderPage("Favorit")
                ),
                shortcutCardLayoutParams()
        );

        shortcuts.addView(
                shortcut(
                        R.drawable.ic_work, "Lamaran", "Pantau lamaran",
                        () -> renderPage("Lamaran")
                ),
                shortcutCardLayoutParams()
        );

        LinearLayout.LayoutParams shortcutRowParams =
                new LinearLayout.LayoutParams(-1, -2);
        shortcutRowParams.setMargins(dp(1), dp(5), dp(1), dp(13));
        content.addView(shortcuts, shortcutRowParams);

        section(
                "Kategori pekerjaan",
                "Lihat semua",
                () -> renderPage("Eksplorasi")
        );

        addCategories();

        section(
                "Lowongan terbaru",
                "Lihat semua",
                () -> renderPage("Eksplorasi")
        );

        showJobs(false);

        section("Persiapan karier", null, null);

        addInfoCard(
                "Pembuat CV",
                "Susun CV profesional dengan data diri, pendidikan, pengalaman, dan keahlian.",
                "Mulai buat CV",
                () -> startActivity(new Intent(MainActivity.this, CVBuilderActivity.class))
        );

        addInfoCard(
                "Tips wawancara",
                "Pelajari strategi, contoh jawaban, dan persiapan sebelum bertemu perekrut.",
                "Mulai belajar",
                () -> startActivity(new Intent(MainActivity.this, InterviewTipsActivity.class))
        );
    }

    private void addPijarHero() {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(22), dp(22), dp(22));
        hero.setBackground(PijarStyle.gradient(this, 0xffffd9df, 0xffffe4bd, 24));
        TextView badge = text("✦  RUANG UNTUK BERTUMBUH", 10, PijarStyle.PURPLE_DARK, true);
        badge.setPadding(dp(10), dp(7), dp(10), dp(7)); badge.setBackground(rounded(0xfffff8f4, 15));
        hero.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        TextView headline = text("Karier impian\ndimulai dari sini.", 23, PijarStyle.INK, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1,-2);titleParams.topMargin=dp(14);hero.addView(headline,titleParams);
        TextView subtitle = text("Temukan peluang yang cocok untuk cerita barumu.", 12, 0xff514659, false);
        subtitle.setLineSpacing(dp(2),1f); LinearLayout.LayoutParams sub = new LinearLayout.LayoutParams(-1,-2);sub.topMargin=dp(6);hero.addView(subtitle,sub);
        TextView action = text("Jelajahi lowongan  →", 12, WHITE, true);
        action.setPadding(dp(16),dp(12),dp(16),dp(12)); action.setGravity(Gravity.CENTER);
        action.setMinHeight(dp(48));action.setBackground(rounded(PijarStyle.PURPLE,14));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-2,-2);ap.topMargin=dp(16);hero.addView(action,ap);
        action.setOnClickListener(v -> renderPage("Eksplorasi"));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(16),0,dp(16));content.addView(hero,p);
    }

    private static class BannerFrame extends FrameLayout {
        BannerFrame(android.content.Context context) { super(context); }
        @Override public boolean performClick() { return super.performClick(); }
    }

    private void addHeroBanner() {
        stopBannerAutoSlide();

        final int[] bannerImages = {
                R.drawable.banner_1,
                R.drawable.banner_2,
                R.drawable.banner_3,
                R.drawable.banner_4,
                R.drawable.banner_5
        };

        BannerFrame bannerFrame = new BannerFrame(this);
        bannerFrame.setBackground(rounded(WHITE, 20));
        bannerFrame.setClipToOutline(true);
        bannerFrame.setElevation(dp(4));

        bannerFlipper = new ViewFlipper(this);
        bannerFlipper.setAutoStart(false);
        bannerFlipper.setFlipInterval(5000);
        bannerFlipper.setInAnimation(this, R.anim.slide_in_right);
        bannerFlipper.setOutAnimation(this, R.anim.slide_out_left);
        bannerFlipper.setMeasureAllChildren(false);

        for (int imageResource : bannerImages) {
            ImageView image = new ImageView(this);
            image.setImageResource(imageResource);
            // Banner sumber berasio 1440x640 (2.25:1); FIT_XY
            // mengisi frame penuh tanpa memotong sisi gambar.
            image.setScaleType(ImageView.ScaleType.FIT_XY);
            image.setContentDescription("Banner informasi karier Pijar Karier");
            image.setBackgroundColor(WHITE);
            bannerFlipper.addView(
                    image,
                    new ViewFlipper.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                    )
            );
        }

        bannerFrame.addView(
                bannerFlipper,
                new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                )
        );

        bannerIndicators = new LinearLayout(this);
        bannerIndicators.setOrientation(LinearLayout.HORIZONTAL);
        bannerIndicators.setGravity(Gravity.CENTER);
        bannerIndicators.setPadding(dp(6), 0, dp(6), 0);
        bannerIndicators.setBackground(rounded(0x660b1656, 10));
        FrameLayout.LayoutParams indicatorParams = new FrameLayout.LayoutParams(-2, dp(18), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        indicatorParams.bottomMargin = dp(3);
        bannerFrame.addView(bannerIndicators, indicatorParams);
        bannerIndicators.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        updateBannerIndicators();
        bannerFrame.setTag(R.id.ui_motion_skip_press, Boolean.TRUE);
        bannerFrame.setOnClickListener(v -> openBannerDestination());
        bannerFrame.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    bannerTouchDownX = event.getX();
                    bannerTouchDownY = event.getY();
                    if (bannerRunnable != null) bannerHandler.removeCallbacks(bannerRunnable);
                    return true;
                case MotionEvent.ACTION_UP:
                    float deltaX = event.getX() - bannerTouchDownX;
                    if (Math.abs(deltaX) > dp(35)) {
                        if (deltaX < 0) {
                            bannerFlipper.setInAnimation(this, R.anim.slide_in_right);
                            bannerFlipper.setOutAnimation(this, R.anim.slide_out_left);
                            bannerFlipper.showNext();
                        } else {
                            bannerFlipper.setInAnimation(this, R.anim.slide_in_left);
                            bannerFlipper.setOutAnimation(this, R.anim.slide_out_right);
                            bannerFlipper.showPrevious();
                        }
                        updateBannerIndicators();
                        restartBannerAutoSlide();
                    } else if (Math.abs(event.getY() - bannerTouchDownY) < dp(25)) {
                        v.performClick();
                    } else {
                        restartBannerAutoSlide();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    restartBannerAutoSlide();
                    return true;
            }
            return true;
        });

        bannerFrame.setClickable(true);
        bannerFrame.setFocusable(true);
        bannerFrame.setContentDescription(
                "Banner Pijar Karier. Ketuk untuk membuka fitur yang ditampilkan, atau geser untuk melihat banner lain."
        );

        float density = getResources().getDisplayMetrics().density;
        int screenWidthDp = (int) (getResources().getDisplayMetrics().widthPixels / density);
        int availableWidthDp = Math.max(1, screenWidthDp - 36);
        int bannerHeightDp = Math.round(availableWidthDp / 2.25f);
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, dp(bannerHeightDp));
        params.setMargins(0, dp(15), 0, dp(12));
        content.addView(bannerFrame, params);

        bannerRunnable = new Runnable() {
            @Override
            public void run() {
                if (bannerFlipper == null || !currentPage.equals("Beranda")) {
                    return;
                }
                bannerFlipper.setInAnimation(MainActivity.this, R.anim.slide_in_right);
                bannerFlipper.setOutAnimation(MainActivity.this, R.anim.slide_out_left);
                bannerFlipper.showNext();
                updateBannerIndicators();
                bannerHandler.postDelayed(this, 5000);
            }
        };
        bannerHandler.postDelayed(bannerRunnable, 5000);
    }


    private void updateBannerIndicators() {
        if (bannerIndicators == null || bannerFlipper == null) return;
        if (bannerIndicators.getChildCount() == 0) {
            for (int i = 0; i < bannerFlipper.getChildCount(); i++) {
                View dot = new View(this);
                dot.setBackground(rounded(WHITE, 10));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(6), dp(6));
                p.setMargins(dp(3), 0, dp(3), 0);
                bannerIndicators.addView(dot, p);
            }
        } else {
            android.transition.ChangeBounds transition = new android.transition.ChangeBounds();
            transition.setDuration(650);
            transition.setInterpolator(new android.view.animation.DecelerateInterpolator());
            android.transition.TransitionManager.beginDelayedTransition(bannerIndicators, transition);
        }
        for (int i = 0; i < bannerIndicators.getChildCount(); i++) {
            View dot = bannerIndicators.getChildAt(i);
            boolean active = i == bannerFlipper.getDisplayedChild();
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) dot.getLayoutParams();
            params.width = dp(active ? 19 : 6);
            dot.setLayoutParams(params);
            dot.animate().alpha(active ? 1f : .48f).setDuration(650).start();
        }
    }

    private void openBannerDestination() {
        if (bannerFlipper == null) return;

        switch (bannerFlipper.getDisplayedChild()) {
            case 0:
            case 1:
                renderPage("Eksplorasi");
                break;
            case 2:
                renderPage("Favorit");
                break;
            case 3:
                renderPage("Lamaran");
                break;
            case 4:
                renderPage("Profil");
                break;
            default:
                renderPage("Eksplorasi");
                break;
        }
    }

    private void restartBannerAutoSlide() {
        if (bannerRunnable == null) return;
        bannerHandler.removeCallbacks(bannerRunnable);
        bannerHandler.postDelayed(bannerRunnable, 5000);
    }

    private void stopBannerAutoSlide() {
        if (bannerRunnable != null) {
            bannerHandler.removeCallbacks(bannerRunnable);
            bannerRunnable = null;
        }
        bannerFlipper = null;
        bannerIndicators = null;
    }

    @Override
    protected void onDestroy() {
        stopBannerAutoSlide();
        super.onDestroy();
    }

    private LinearLayout.LayoutParams shortcutCardLayoutParams() {
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(0, -1, 1f);
        params.setMargins(dp(5), 0, dp(5), 0);
        return params;
    }

    private View shortcut(
            int iconResource,
            String title,
            String subtitle,
            Runnable action
    ) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(7), dp(15), dp(7), dp(15));
        card.setMinimumHeight(dp(132));
        int pastel = title.equals("Cari kerja") ? 0xffffe2e9 : title.equals("Favorit") ? 0xffe9e0ff : PijarStyle.MINT;
        card.setBackground(rounded(pastel, 20));
        card.setElevation(dp(0));
        card.setClickable(true);
        card.setFocusable(true);

        FrameLayout iconContainer = new FrameLayout(this);
        iconContainer.setBackground(rounded(WHITE, 15));
        iconContainer.setClipToOutline(true);

        ImageView iconView = new ImageView(this);
        iconView.setImageResource(iconResource);
        iconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iconView.setColorFilter(BLUE);
        iconView.setPadding(dp(10), dp(10), dp(10), dp(10));
        iconContainer.addView(iconView, new FrameLayout.LayoutParams(
                dp(46), dp(46), Gravity.CENTER
        ));

        LinearLayout.LayoutParams iconParams =
                new LinearLayout.LayoutParams(dp(46), dp(46));
        iconParams.bottomMargin = dp(10);
        card.addView(iconContainer, iconParams);

        TextView titleView = text(title, 11, TEXT, true);
        titleView.setGravity(Gravity.CENTER);
        titleView.setMaxLines(2);
        titleView.setIncludeFontPadding(false);
        card.addView(titleView, new LinearLayout.LayoutParams(-1, -2));

        TextView subView = text(subtitle, 10, MUTED, false);
        subView.setGravity(Gravity.CENTER);
        subView.setMaxLines(2);
        subView.setIncludeFontPadding(false);
        LinearLayout.LayoutParams subParams =
                new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(5);
        card.addView(subView, subParams);

        UiMotion.bindPress(card);
        card.setOnClickListener(v -> action.run());

        return card;
    }

    private void addCategories() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);

        LinearLayout categories = row();

        String[] names = {
                "Semua", "IT & Software",
                "Administrasi", "Marketing",
                "Keuangan", "Desain",
                "Pendidikan", "Kesehatan",
                "Customer Service"
        };

        for (String name : names) {
            TextView category = text(
                    name, 11,
                    selectedCategory.equals(name) ? WHITE : BLUE,
                    true
            );

            category.setGravity(Gravity.CENTER);
            category.setPadding(
                    dp(14), dp(10), dp(14), dp(10)
            );

            category.setBackground(
                    rounded(
                            selectedCategory.equals(name)
                                    ? BLUE : WHITE,
                            22
                    )
            );

            category.setOnClickListener(v -> {
                selectedCategory = name;

                userPrefs.edit()
                        .putString("category", name)
                        .apply();

                renderPage("Eksplorasi");
            });

            LinearLayout.LayoutParams params =
                    new LinearLayout.LayoutParams(-2, -2);

            params.setMargins(0, 0, dp(8), 0);
            categories.addView(category, params);
        }

        scroll.addView(categories);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, -2);

        params.bottomMargin = dp(8);
        content.addView(scroll, params);
    }

    private void explorePage() {
        addPageIntro("EKSPLORASI", "Eksplorasi pekerjaan", "Cari pekerjaan berdasarkan kategori dan kata kunci.");

        LinearLayout filters = row();

        TextView all = chip("Semua kategori");
        all.setOnClickListener(v -> {
            selectedCategory = "Semua";
            userPrefs.edit()
                    .putString("category", selectedCategory)
                    .apply();
            renderPage("Eksplorasi");
        });

        TextView reset = chip("Reset pencarian");
        reset.setOnClickListener(v -> {
            selectedCategory = "Semua";
            searchQuery = "";

            ignoreSearchChange = true;
            searchInput.setText("");
            ignoreSearchChange = false;

            userPrefs.edit()
                    .putString("category", selectedCategory)
                    .apply();

            renderPage("Eksplorasi");
        });

        filters.addView(all);
        filters.addView(reset);
        content.addView(filters);

        section("Daftar lowongan", null, null);
        showJobs(true);
    }

    private void showJobs(boolean showAll) {
        int shown = 0;

        for (JSONObject job : jobs) {
            String category = job.optString("kategori", "");

            String searchable = (
                    job.optString("judul", "") + " "
                            + job.optString("perusahaan", "") + " "
                            + job.optString("lokasi", "") + " "
                            + category
            ).toLowerCase(Locale.ROOT);

            boolean categoryMatch =
                    selectedCategory.equals("Semua")
                            || category.equalsIgnoreCase(selectedCategory);

            boolean queryMatch =
                    searchQuery.isEmpty()
                            || searchable.contains(
                            searchQuery.toLowerCase(Locale.ROOT)
                    );

            if (!categoryMatch || !queryMatch) continue;

            content.addView(jobCard(job));
            shown++;

            if (!showAll && shown >= 4) break;
        }

        if (shown == 0) {
            addInfoCard(
                    isLoading
                            ? "Memuat lowongan..."
                            : jobs.isEmpty()
                            ? "Lowongan belum tersedia"
                            : "Lowongan tidak ditemukan",
                    jobs.isEmpty()
                            ? "Periksa koneksi internet atau endpoint API lowongan."
                            : "Coba kata kunci atau kategori lainnya.",
                    "Muat ulang",
                    this::loadJobs
            );
        }
    }

    private View jobCard(JSONObject job) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(
                dp(18), dp(18), dp(18), dp(18)
        );
        card.setBackground(rounded(WHITE, 22));
        card.setElevation(dp(1));

        LinearLayout.LayoutParams cardParams =
                new LinearLayout.LayoutParams(-1, -2);

        cardParams.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(cardParams);

        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);

        String company = job.optString("perusahaan", "Perusahaan");

        TextView logo = text(initials(company), 15, WHITE, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(gradient(BLUE_DARK, BLUE));

        top.addView(
                logo,
                new LinearLayout.LayoutParams(dp(47), dp(47))
        );

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(11), 0, dp(5), 0);

        info.addView(text(
                job.optString("judul", "Lowongan pekerjaan"),
                14, TEXT, true
        ));

        info.addView(text(company, 12, MUTED, false));

        top.addView(
                info,
                new LinearLayout.LayoutParams(0, -2, 1)
        );

        String id = job.optString("id");

        FrameLayout favoriteButton = new FrameLayout(this);
        favoriteButton.setBackground(rounded(
                favorites.contains(id) ? BLUE_LIGHT : BACKGROUND, 14
        ));
        favoriteButton.setClickable(true);
        favoriteButton.setFocusable(true);
        favoriteButton.setContentDescription(
                favorites.contains(id) ? "Hapus dari favorit" : "Simpan ke favorit"
        );

        ImageView heart = new ImageView(this);
        heart.setImageResource(R.drawable.ic_favorite);
        heart.setColorFilter(favorites.contains(id) ? BLUE : MUTED);
        heart.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams heartParams = new FrameLayout.LayoutParams(
                dp(21), dp(21), Gravity.CENTER
        );
        favoriteButton.addView(heart, heartParams);

        LinearLayout.LayoutParams favoriteButtonParams =
                new LinearLayout.LayoutParams(dp(48), dp(48));
        top.addView(favoriteButton, favoriteButtonParams);

        favoriteButton.setOnClickListener(v -> toggleFavorite(id));

        card.addView(top);

        LinearLayout tags = row();
        tags.setPadding(0, dp(11), 0, dp(9));

        tags.addView(chip(job.optString("kategori", "Umum")));
        tags.addView(chip(job.optString("tipe", "Pekerjaan")));

        HorizontalScrollView tagScroll = new HorizontalScrollView(this);
        tagScroll.setHorizontalScrollBarEnabled(false);
        tagScroll.addView(tags);
        card.addView(tagScroll);

        card.addView(text(
                "Lokasi: " + job.optString(
                        "lokasi", "Tidak disebutkan"
                ),
                12, MUTED, false
        ));

        String salary = formatSalary(
                job.optString("gaji_min", ""),
                job.optString("gaji_max", "")
        );

        if (!salary.isEmpty()) {
            TextView salaryView = text(
                    salary, 14, BLUE, true
            );

            LinearLayout.LayoutParams salaryParams =
                    new LinearLayout.LayoutParams(-1, -2);

            salaryParams.topMargin = dp(8);
            card.addView(salaryView, salaryParams);
        }

        TextView detail = text(
                "Lihat detail lowongan  →",
                12, BLUE, true
        );

        LinearLayout.LayoutParams detailParams =
                new LinearLayout.LayoutParams(-1, -2);

        detailParams.topMargin = dp(11);
        card.addView(detail, detailParams);

        card.setOnClickListener(v -> showJobDetail(job));

        return card;
    }

    private void toggleFavorite(String id) {
        if (id == null || id.trim().isEmpty()) {
            toast("ID lowongan tidak tersedia");
            return;
        }

        if (favorites.contains(id)) {
            favorites.remove(id);
            toast("Dihapus dari favorit");
        } else {
            favorites.add(id);
            toast("Disimpan ke favorit");
        }

        favoritePrefs.edit()
                .putStringSet(
                        KEY_FAVORITES,
                        new HashSet<>(favorites)
                )
                .apply();

        renderPage(currentPage);
    }

    private void favoritePage() {
        addPageIntro("FAVORIT", "Lowongan favorit", "Kumpulan pekerjaan yang kamu simpan.");

        int count = 0;

        for (JSONObject job : jobs) {
            if (favorites.contains(job.optString("id"))) {
                content.addView(jobCard(job));
                count++;
            }
        }

        if (count == 0) {
            addInfoCard(
                    "Belum ada favorit",
                    "Tekan ikon hati pada lowongan untuk menyimpannya.",
                    "Cari lowongan",
                    () -> renderPage("Eksplorasi")
            );
        }
    }

    private void applicationPage() {
        addPageIntro("LAMARAN", "Lamaran saya", "Pantau perkembangan proses rekrutmenmu.");
        LinearLayout records = new LinearLayout(this);
        records.setOrientation(LinearLayout.VERTICAL);
        TextView loading = text("Memuat riwayat lamaran…", 12, MUTED, false); records.addView(loading);
        content.addView(records);
        ApiClient.post(this, "profile/applications.php", new java.util.HashMap<>(), new ApiClient.Result() {
            public void success(JSONObject result) {
                records.removeAllViews(); JSONArray a=result.optJSONArray("applications");
                if(a==null || a.length()==0) {records.addView(text("Belum ada riwayat lamaran di server.",13,MUTED,false));return;}
                for(int i=0;i<a.length();i++) {JSONObject r=a.optJSONObject(i); if(r==null) continue;
                    LinearLayout card=new LinearLayout(MainActivity.this);card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(17),dp(16),dp(17),dp(16));card.setBackground(rounded(WHITE,20));
                    card.addView(text(r.optString("judul","Lowongan"),15,TEXT,true));
                    TextView company=text(r.optString("perusahaan", "Perusahaan") + "  •  " + r.optString("lokasi", ""),12,MUTED,false);
                    company.setPadding(0,dp(5),0,dp(8));card.addView(company);
                    TextView state=text("STATUS  /  " + r.optString("status","menunggu").toUpperCase(Locale.ROOT),11,BLUE_DARK,true);card.addView(state);
                    TextView date=text(r.optString("created_at", ""),11,MUTED,false);date.setPadding(0,dp(5),0,0);card.addView(date);
                    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);records.addView(card,lp);
                }
                UiMotion.revealChildren(records,40,55,6);
            }
            public void fail(String message) { records.removeAllViews(); records.addView(text(message,12,RED,false)); }
        });
        addInfoCard("Catatan tindak lanjut", "Buat catatan untuk membantu memantau proses rekrutmen.", "Buat catatan", this::followUpNote);
    }

    @Override
    protected void onPause() {
        if (bannerRunnable != null) bannerHandler.removeCallbacks(bannerRunnable);
        UiMotion.finishReveals(root);
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bannerRunnable != null && "Beranda".equals(currentPage)) restartBannerAutoSlide();
        if (content != null && "Profil".equals(currentPage)) {
            username = userPrefs.getString("username", userPrefs.getString("nama", username));
            if (username == null || username.trim().isEmpty()) username = userPrefs.getString("nama", "Pengguna");
            email = userPrefs.getString("email", email);
            phone = userPrefs.getString("phone", userPrefs.getString("no_hp", phone));
            renderPage("Profil");
        } else if (content != null && "Lamaran".equals(currentPage)) {
            renderPage("Lamaran");
        }
    }

    private void profilePage() {
        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, dp(2), 0, dp(16));
        ImageView menu = new ImageView(this);
        menu.setImageResource(R.drawable.ic_lk_menu);
        menu.setColorFilter(BLUE_DARK);
        menu.setPadding(dp(12), dp(12), dp(12), dp(12));
        menu.setBackground(rounded(WHITE, 15));
        menu.setContentDescription("Buka pusat akun");
        header.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(48)));
        menu.setOnClickListener(v -> showProfileMenu());
        LinearLayout title = new LinearLayout(this);
        title.setOrientation(LinearLayout.VERTICAL);
        title.setPadding(dp(12), 0, 0, 0);
        title.addView(text("RUANG KARIER", 10, BLUE_DARK, true));
        title.addView(text("Profil saya", 22, TEXT, true));
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(header);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(20), dp(18), dp(20));
        card.setBackground(rounded(WHITE, 24));
        card.setElevation(dp(3));
        LinearLayout identity = row();
        identity.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout avatarRing = new FrameLayout(this);
        GradientDrawable ring = rounded(BLUE_LIGHT, 100);
        ring.setStroke(dp(2), BLUE); avatarRing.setBackground(ring);
        avatarRing.setPadding(dp(4),dp(4),dp(4),dp(4));
        FrameLayout avatarFrame = new FrameLayout(this);
        avatarFrame.setBackground(rounded(WHITE,100)); avatarFrame.setClipToOutline(true);
        avatarRing.addView(avatarFrame, new FrameLayout.LayoutParams(-1,-1));
        ImageView avatar = new ImageView(this); avatar.setImageResource(R.drawable.ic_lk_person);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarFrame.addView(avatar, new FrameLayout.LayoutParams(-1,-1));
        avatarRing.setContentDescription("Kelola foto profil");
        avatarRing.setOnClickListener(v -> showPhotoActions()); loadProfilePhoto(avatar);
        identity.addView(avatarRing, new LinearLayout.LayoutParams(dp(78),dp(78)));
        LinearLayout stats = row(); stats.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0,-2,1); sp.leftMargin=dp(12);
        identity.addView(stats,sp);
        TextView applicationsCount = addProfileStat(stats, "—", "Lamaran", () -> renderPage("Lamaran"));
        ApiClient.post(this, "profile/stats.php", new java.util.HashMap<>(), new ApiClient.Result() {
            public void success(JSONObject result) { applicationsCount.setText(String.valueOf(result.optInt("applications_count", 0))); }
            public void fail(String message) { applicationsCount.setText("—"); }
        });
        addProfileStat(stats, String.valueOf(favorites.size()), "Favorit", () -> renderPage("Favorit"));
        card.addView(identity);
        String displayName = userPrefs.getString("nama", "");
        if (displayName == null || displayName.trim().isEmpty()) displayName = username;
        if (displayName == null || displayName.trim().isEmpty()) displayName = "Pengguna Pijar Karier";
        TextView name = text(displayName,20,TEXT,true); name.setMaxLines(3);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(16); card.addView(name,np);
        String handleValue = userPrefs.getString("username", "");
        TextView handle = text(handleValue == null || handleValue.trim().isEmpty() ? "Lengkapi nama pengguna" : "@" + handleValue,12,MUTED,false);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(3); card.addView(handle,hp);
        TextView note = text("Ruang untuk menunjukkan perjalanan dan pencapaian kariermu.",12,MUTED,false);
        note.setLineSpacing(dp(2),1f);
        LinearLayout.LayoutParams n = new LinearLayout.LayoutParams(-1,-2); n.topMargin=dp(10); card.addView(note,n);
        LinearLayout actions = row();
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1,-2); ap.topMargin=dp(16); card.addView(actions,ap);
        TextView edit = text("Edit profil",13,WHITE,true); edit.setGravity(Gravity.CENTER);
        edit.setBackground(gradient(BLUE_DARK,BLUE)); edit.setOnClickListener(v -> openProfileEditor());
        edit.setMinHeight(dp(48)); edit.setPadding(dp(6),dp(8),dp(6),dp(8));
        actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1));
        TextView photo = text("Kelola foto",13,BLUE_DARK,true); photo.setGravity(Gravity.CENTER);
        photo.setBackground(rounded(BLUE_LIGHT,16)); photo.setOnClickListener(v -> showPhotoActions());
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0,-2,1); photo.setMinHeight(dp(48)); photo.setPadding(dp(6),dp(8),dp(6),dp(8)); pp.leftMargin=dp(9); actions.addView(photo,pp);
        content.addView(card);

        section("Galeri sertifikat", null, null);
        LinearLayout galleryHead = row(); galleryHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView galleryInfo = text("Pencapaian publik", 12, MUTED, false);
        galleryHead.addView(galleryInfo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView galleryAdd = text("+ Tambah / kelola", 12, BLUE_DARK, true);
        galleryAdd.setPadding(dp(10), dp(10), dp(10), dp(10));
        galleryAdd.setBackground(rounded(BLUE_LIGHT, 14));
        galleryAdd.setOnClickListener(v -> startActivity(new Intent(this, CertificatesActivity.class)));
        galleryHead.addView(galleryAdd); content.addView(galleryHead);
        LinearLayout gallery = new LinearLayout(this); gallery.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams galleryParams = new LinearLayout.LayoutParams(-1, -2);
        galleryParams.topMargin = dp(10); content.addView(gallery, galleryParams);
        CertificateGallery.show(this, gallery);
        section("Informasi akun", null, null);
        LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(18),dp(5),dp(18),dp(5)); details.setBackground(rounded(WHITE,22));
        addProfileDetail(details, "Email", email.isEmpty() ? "Belum diisi" : email, R.drawable.ic_lk_mail);
        addProfileDetail(details, "Nomor telepon", phone.isEmpty() ? "Belum diisi" : phone, R.drawable.ic_lk_phone);
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(-1,-2);
        detailsParams.bottomMargin = dp(16);
        content.addView(details, detailsParams);
        addInfoCard("Preferensi pekerjaan", "Atur kategori lowongan sesuai minatmu.", "Atur preferensi", this::editPreferences);
    }

    private TextView addProfileStat(LinearLayout parent, String value, String label, Runnable action) {
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER);
        TextView number=text(value,19,TEXT,true); number.setGravity(Gravity.CENTER); col.addView(number);
        TextView caption=text(label,11,MUTED,false); caption.setGravity(Gravity.CENTER); col.addView(caption);
        col.setContentDescription(label + ": " + value); col.setOnClickListener(v -> action.run());
        parent.addView(col,new LinearLayout.LayoutParams(0,dp(60),1));
        return number;
    }

    private void addProfileDetail(LinearLayout parent, String label, String value, int symbol) {
        LinearLayout item = row();
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(0, dp(12), 0, dp(12));
        ImageView icon = new ImageView(this);
        icon.setImageResource(symbol);
        icon.setColorFilter(BLUE_DARK);
        icon.setPadding(dp(9), dp(9), dp(9), dp(9));
        icon.setBackground(rounded(BLUE_LIGHT, 12));
        item.addView(icon, new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(12), 0, 0, 0);
        texts.addView(text(label, 11, MUTED, false));
        TextView valueView = text(value, 14, TEXT, true);
        valueView.setMaxLines(2);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(-1, -2);
        valueParams.topMargin = dp(3);
        texts.addView(valueView, valueParams);
        item.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));
        parent.addView(item);
        if ("Email".equals(label)) {
            View line = new View(this); line.setBackgroundColor(BORDER);
            parent.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        }
    }

    private void showProfileMenu() {
        Dialog dialog = new Dialog(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(26), dp(16), dp(18));
        panel.setBackgroundColor(WHITE);

        LinearLayout heading = row();
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("L", 20, WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(gradient(BLUE_DARK, BLUE));
        heading.addView(mark, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView brand = text("Pusat akun", 18, TEXT, true);
        brand.setPadding(dp(10), 0, 0, 0);
        heading.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = text("×", 26, MUTED, false);
        close.setGravity(Gravity.CENTER);
        close.setContentDescription("Tutup menu");
        heading.addView(close, new LinearLayout.LayoutParams(dp(42), dp(48)));
        close.setOnClickListener(v -> dialog.dismiss());
        panel.addView(heading);
        TextView descriptor = text("AKUN & INFORMASI", 10, MUTED, true);
        descriptor.setLetterSpacing(.08f);
        LinearLayout.LayoutParams descriptorParams = new LinearLayout.LayoutParams(-1, -2);
        descriptorParams.topMargin = dp(24);
        descriptorParams.bottomMargin = dp(8);
        panel.addView(descriptor, descriptorParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout items = new LinearLayout(this);
        items.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(items);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        addMenuOption(items, dialog, "Profil dan data pribadi", "Lihat dan ubah profil", R.drawable.ic_lk_person, this::openProfileEditor);
        addMenuOption(items, dialog, "Pusat akun", "Keamanan dan pengelolaan akun", R.drawable.ic_lk_shield_check, () -> startActivity(new Intent(this, AccountCenterActivity.class)));
        addMenuOption(items, dialog, "Sertifikat publik", "Kelola pencapaian", R.drawable.ic_lk_info_outline, () -> startActivity(new Intent(this, CertificatesActivity.class)));
        addMenuOption(items, dialog, "Pusat bantuan", "Panduan aplikasi", R.drawable.ic_lk_help, () -> showMessage(
                "Pusat bantuan", "Gunakan Beranda dan Eksplorasi untuk menemukan lowongan, Favorit untuk menyimpan pekerjaan, dan halaman Profil untuk mengelola data akun. Jika membutuhkan bantuan lebih lanjut, hubungi pengelola aplikasi."));
        addMenuOption(items, dialog, "Tentang Pijar Karier", "Informasi aplikasi", R.drawable.ic_lk_info_outline, () -> showMessage(
                "Tentang Pijar Karier", "Pijar Karier membantu kamu menemukan lowongan pekerjaan, menyimpan pekerjaan favorit, dan mempersiapkan karier."));
        addMenuOption(panel, dialog, "Keluar akun", "Akhiri sesi", R.drawable.ic_logout, this::logout);
        dialog.setContentView(panel);
        UiMotion.bindActions(panel);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setGravity(Gravity.LEFT | Gravity.TOP);
            dialog.getWindow().setWindowAnimations(R.style.LokerkuDrawerAnimations);
        }
        dialog.show();
        android.view.Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setGravity(Gravity.LEFT | Gravity.TOP);
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            android.view.WindowManager.LayoutParams attrs = window.getAttributes();
            attrs.dimAmount = .48f;
            window.setAttributes(attrs);
            window.setWindowAnimations(R.style.LokerkuDrawerAnimations);
            window.setLayout(Math.min((int)(getResources().getDisplayMetrics().widthPixels * .60f), dp(310)), ViewGroup.LayoutParams.MATCH_PARENT);
        }
        UiMotion.revealChildren(items, 80, 70, 3);
    }

    private void addMenuOption(LinearLayout panel, Dialog dialog, String title, String description, int symbol, Runnable action) {
        LinearLayout item = row();
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(dp(10), dp(10), dp(8), dp(10));
        item.setBackground(rounded(BACKGROUND, 16));
        ImageView icon = new ImageView(this);
        icon.setImageResource(symbol);
        icon.setColorFilter(BLUE_DARK);
        icon.setPadding(dp(10), dp(10), dp(10), dp(10));
        icon.setBackground(rounded(BLUE_LIGHT, 12));
        item.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(10), 0, 0, 0);
        copy.addView(text(title, 13, TEXT, true));
        TextView sub = text(description, 10, MUTED, false);
        sub.setMaxLines(2);
        copy.addView(sub);
        item.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(-1, -2);
        itemParams.topMargin = dp(8);
        panel.addView(item, itemParams);
        item.setOnClickListener(v -> { dialog.dismiss(); action.run(); });
    }

    private void openProfileEditor() {
        Intent intent = new Intent(this, ProfileActivity.class);
        startActivity(intent);
    }

    private void showPhotoActions() {
        String[] options = {"Ganti / unggah foto", "Hapus foto profil", "Batal"};
        new PremiumDialog.Builder(this)
                .setTitle("Foto profil")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        openProfileEditor();
                    } else if (which == 1) {
                        ApiClient.post(this, "auth/delete_photo.php", new java.util.HashMap<>(), new ApiClient.Result() {
                            public void success(JSONObject json) {userPrefs.edit().remove("foto").apply();renderPage("Profil");toast("Foto profil dihapus.");}
                            public void fail(String message) {toast(message);}
                        });
                    }
                })
                .show();
    }

    private void loadProfilePhoto(ImageView avatar) {
        String photo = userPrefs.getString("foto", "");
        if (photo == null || photo.trim().isEmpty()) return;
        if (photo.startsWith("https://") || photo.startsWith("http://")) {
            com.android.volley.toolbox.ImageRequest request = new com.android.volley.toolbox.ImageRequest(
                    photo,
                    bitmap -> avatar.setImageBitmap(bitmap),
                    256,
                    256,
                    ImageView.ScaleType.CENTER_CROP,
                    android.graphics.Bitmap.Config.RGB_565,
                    error -> { }
            );
            Volley.newRequestQueue(getApplicationContext()).add(request);
        } else {
            try {
                avatar.setImageURI(android.net.Uri.parse(photo));
            } catch (Exception ignored) { }
        }
    }

    private void editProfile() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(4), dp(5), dp(4), dp(4));

        EditText nameInput = createInput("Nama pengguna");
        nameInput.setText(username);

        EditText emailInput = createInput("Email");
        emailInput.setInputType(
                android.text.InputType.TYPE_CLASS_TEXT
                        | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        );
        emailInput.setText(email);

        EditText phoneInput = createInput("Nomor HP");
        phoneInput.setInputType(
                android.text.InputType.TYPE_CLASS_PHONE
        );
        phoneInput.setText(phone);

        form.addView(nameInput);
        form.addView(emailInput);
        form.addView(phoneInput);

        new PremiumDialog.Builder(this)
                .setTitle("Edit profil")
                .setView(form)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String newName = nameInput.getText()
                            .toString().trim();

                    if (newName.isEmpty()) {
                        toast("Nama tidak boleh kosong");
                        return;
                    }

                    username = newName;
                    email = emailInput.getText()
                            .toString().trim();
                    phone = phoneInput.getText()
                            .toString().trim();

                    userPrefs.edit()
                            .putString("username", username)
                            .putString("nama", username)
                            .putString("email", email)
                            .putString("phone", phone)
                            .putString("no_hp", phone)
                            .apply();

                    renderPage("Profil");
                    toast("Profil disimpan di perangkat");
                })
                .show();
    }

    private void editPreferences() {
        String[] options = {
                "Semua",
                "IT & Software",
                "Administrasi",
                "Marketing",
                "Keuangan",
                "Desain",
                "Pendidikan",
                "Kesehatan",
                "Customer Service"
        };

        new PremiumDialog.Builder(this)
                .setTitle("Preferensi pekerjaan")
                .setSingleChoiceItems(
                        options,
                        Math.max(
                                0,
                                java.util.Arrays.asList(options)
                                        .indexOf(selectedCategory)
                        ),
                        (dialog, which) -> {
                            selectedCategory = options[which];

                            userPrefs.edit()
                                    .putString(
                                            "category",
                                            selectedCategory
                                    )
                                    .apply();

                            dialog.dismiss();
                            renderPage("Eksplorasi");
                        }
                )
                .setNegativeButton("Batal", null)
                .show();
    }

    private void followUpNote() {
        EditText input = createInput("Tulis catatan tindak lanjut");
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setGravity(Gravity.TOP | Gravity.START);
        LinearLayout noteForm = new LinearLayout(this);
        noteForm.setOrientation(LinearLayout.VERTICAL);
        noteForm.setPadding(dp(20), dp(6), dp(20), dp(4));
        noteForm.addView(input, new LinearLayout.LayoutParams(-1, dp(110)));

        new PremiumDialog.Builder(this)
                .setTitle("Catatan tindak lanjut")
                .setMessage("Catatan ini disimpan di perangkatmu.")
                .setView(noteForm)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", (dialog, which) -> {
                    String note = input.getText().toString().trim();

                    if (note.isEmpty()) {
                        toast("Catatan masih kosong");
                        return;
                    }

                    SharedPreferences notes = getSharedPreferences(
                            "lokerku_notes_" + userPrefs.getInt("id", 0), MODE_PRIVATE
                    );

                    String oldNotes = notes.getString("notes", "");

                    String updated = oldNotes.isEmpty()
                            ? note
                            : oldNotes + "\n\n" + note;

                    notes.edit().putString("notes", updated).apply();

                    toast("Catatan tersimpan di perangkat");
                })
                .show();
    }

    private void logout() {
        new PremiumDialog.Builder(this)
                .setTitle("Keluar akun")
                .setMessage("Apakah kamu yakin ingin keluar dari Pijar Karier?")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Keluar", (dialog, which) -> {
                    ApiClient.post(this, "auth/logout.php", new java.util.HashMap<>(), new ApiClient.Result() {
                        public void success(JSONObject ignored) { }
                        public void fail(String ignored) { }
                    });
                    SessionStore.clear(this);
                    userPrefs.edit().clear().apply();
                    Intent login = new Intent(this, LoginActivity.class);
                    login.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(login); finish();
                })
                .show();
    }

    private void loadJobs() {
        if (isLoading) return;

        isLoading = true;

        StringRequest request = new StringRequest(
                Request.Method.GET,
                API_JOBS,
                response -> {
                    isLoading = false;

                    try {
                        JSONObject result = new JSONObject(response);

                        if (!result.optBoolean("success", false)) {
                            toast(result.optString(
                                    "message",
                                    "Data lowongan gagal dimuat"
                            ));

                            renderPage(currentPage);
                            return;
                        }

                        JSONArray data = result.optJSONArray("data");

                        if (data == null) {
                            JSONObject nested = result.optJSONObject("data");

                            if (nested != null) {
                                data = nested.optJSONArray("jobs");
                            }
                        }

                        jobs.clear();

                        if (data != null) {
                            for (int i = 0; i < data.length(); i++) {
                                JSONObject item = data.optJSONObject(i);

                                if (item != null) {
                                    jobs.add(item);
                                }
                            }
                        }

                        renderPage(currentPage);

                    } catch (Exception e) {
                        renderPage(currentPage);
                        toast("Format respons API tidak sesuai");
                    }
                },
                error -> {
                    isLoading = false;
                    renderPage(currentPage);
                    toast("Koneksi lowongan gagal. Periksa internet dan API.");
                }
        );

        request.setShouldCache(false);

        request.setRetryPolicy(
                new com.android.volley.DefaultRetryPolicy(
                        15000,
                        1,
                        1.0f
                )
        );

        Volley.newRequestQueue(getApplicationContext()).add(request);
    }

    private void showJobDetail(JSONObject job) {
        Intent intent = new Intent(this, JobDetailActivity.class);
        intent.putExtra("job_json", job.toString());
        startActivity(intent);
        overridePendingTransition(R.anim.screen_enter, R.anim.screen_exit);
    }

    private void addPageIntro(String eyebrow, String title, String description) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20), dp(20), dp(20), dp(19));
        int introStart = PijarStyle.PURPLE_DARK, introEnd = 0xff9a4c93;
        if ("EKSPLORASI".equals(eyebrow)) { introStart = 0xff112a67; introEnd = 0xff2864e7; }
        else if ("FAVORIT".equals(eyebrow)) { introStart = 0xff242071; introEnd = 0xff5951da; }
        else if ("LAMARAN".equals(eyebrow)) { introStart = 0xff163657; introEnd = 0xff1a72c9; }
        panel.setBackground(gradient(introStart, introEnd));
        TextView label = text(eyebrow + "  /  PIJAR KARIER", 10, Color.rgb(213, 224, 255), true);
        label.setLetterSpacing(0.08f);
        panel.addView(label);
        TextView heading = text(title, 22, WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(8);
        panel.addView(heading, hp);
        TextView detail = text(description, 12, Color.rgb(231, 235, 255), false);
        detail.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(-1, -2);
        detailParams.topMargin = dp(7);
        panel.addView(detail, detailParams);
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-1, -2);
        outer.bottomMargin = dp(18);
        content.addView(panel, outer);
    }

    private void addInfoCard(
            String title,
            String description,
            String actionLabel,
            Runnable action
    ) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(
                dp(16), dp(15), dp(16), dp(15)
        );
        card.setBackground(rounded(WHITE, 18));
        card.setElevation(dp(2));

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, -2);

        params.setMargins(0, 0, 0, dp(11));
        card.setLayoutParams(params);

        card.addView(text(title, 14, TEXT, true));

        TextView descriptionView = text(
                description, 11, MUTED, false
        );

        LinearLayout.LayoutParams descriptionParams =
                new LinearLayout.LayoutParams(-1, -2);

        descriptionParams.topMargin = dp(5);
        card.addView(descriptionView, descriptionParams);

        TextView actionView = text(
                actionLabel + "  →", 12, BLUE, true
        );

        LinearLayout.LayoutParams actionParams =
                new LinearLayout.LayoutParams(-1, -2);

        actionParams.topMargin = dp(10);
        card.addView(actionView, actionParams);

        card.setOnClickListener(v -> action.run());

        content.addView(card);
    }

    private void section(
            String title,
            String actionLabel,
            Runnable action
    ) {
        LinearLayout header = row();
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, dp(20), 0, dp(12));

        TextView titleView = text(title, 16, TEXT, true);

        header.addView(
                titleView,
                new LinearLayout.LayoutParams(0, -2, 1)
        );

        if (actionLabel != null && action != null) {
            TextView actionView = text(
                    actionLabel, 11, BLUE, true
            );

            header.addView(actionView);
            actionView.setOnClickListener(v -> action.run());
        }

        content.addView(header);
    }

    private void addText(
            String value,
            int size,
            int color,
            boolean bold
    ) {
        TextView view = text(value, size, color, bold);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, -2);

        params.bottomMargin = dp(5);

        content.addView(view, params);
    }

    private TextView chip(String label) {
        TextView view = text(label, 10, BLUE, true);
        view.setGravity(Gravity.CENTER);
        view.setPadding(
                dp(11), dp(8), dp(11), dp(8)
        );
        view.setBackground(rounded(BLUE_LIGHT, 20));

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-2, -2);

        params.setMargins(0, 0, dp(7), 0);
        view.setLayoutParams(params);

        return view;
    }

    private EditText createInput(String hint) {
        EditText input = new EditText(this);

        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(13);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setTypeface(AppFont.regular(this));
        input.setPadding(
                dp(12), dp(8), dp(12), dp(8)
        );
        input.setBackground(rounded(BACKGROUND, 12));

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(-1, -2);
        input.setMinHeight(dp(48));

        params.setMargins(0, dp(5), 0, dp(7));
        input.setLayoutParams(params);

        return input;
    }

    private TextView text(
            String value,
            int size,
            int color,
            boolean bold
    ) {
        TextView view = new TextView(this);

        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(false);
        view.setTypeface(
                bold
                        ? AppFont.semibold(this)
                        : AppFont.regular(this)
        );

        return view;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        if (color == WHITE) drawable.setStroke(dp(1), BORDER);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private GradientDrawable gradient(int start, int end) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{start, end}
        );

        drawable.setCornerRadius(dp(22));
        return drawable;
    }

    private int dp(float value) {
        return (int) (
                value * getResources()
                        .getDisplayMetrics().density + 0.5f
        );
    }

    private String initials(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "LK";
        }

        String[] parts = name.trim().split("\\s+");

        if (parts.length == 1) {
            return parts[0].substring(
                    0, Math.min(2, parts[0].length())
            ).toUpperCase(Locale.ROOT);
        }

        return (
                parts[0].substring(0, 1)
                        + parts[1].substring(0, 1)
        ).toUpperCase(Locale.ROOT);
    }

    private String formatSalary(String minimum, String maximum) {
        if ((minimum == null || minimum.isEmpty())
                && (maximum == null || maximum.isEmpty())) {
            return "";
        }

        try {
            long min = minimum == null || minimum.isEmpty()
                    ? 0 : Long.parseLong(minimum);

            long max = maximum == null || maximum.isEmpty()
                    ? 0 : Long.parseLong(maximum);

            if (min > 0 && max > 0) {
                return "Rp " + String.format(
                        Locale.US, "%,d", min
                ).replace(',', '.') + " - Rp " + String.format(
                        Locale.US, "%,d", max
                ).replace(',', '.');
            }

            long value = min > 0 ? min : max;

            return "Mulai Rp " + String.format(
                    Locale.US, "%,d", value
            ).replace(',', '.');

        } catch (Exception e) {
            return "";
        }
    }

    private void showNotificationsDialog() {
        Dialog dialog = new Dialog(this);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(WHITE, 26));
        panel.setClipToOutline(true);

        // Header premium dengan gradasi biru khas LokerKu.
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22), dp(22), dp(22), dp(22));
        hero.setBackground(gradient(BLUE_DARK, BLUE));

        LinearLayout heroTop = row();
        FrameLayout bellBubble = new FrameLayout(this);
        bellBubble.setBackground(rounded(PijarStyle.PURPLE, 16));
        ImageView bell = new ImageView(this);
        bell.setImageResource(R.drawable.ic_notifications);
        bell.setColorFilter(WHITE);
        bell.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams bellParams = new FrameLayout.LayoutParams(
                dp(25), dp(25), Gravity.CENTER
        );
        bellBubble.addView(bell, bellParams);
        heroTop.addView(bellBubble, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        titleBlock.setPadding(dp(12), 0, 0, 0);
        titleBlock.addView(text("Notifikasi", 21, WHITE, true));
        TextView subtitle = text(
                "Pusat informasi aktivitasmu", 12,
                Color.rgb(224, 229, 255), false
        );
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-2, -2);
        subtitleParams.topMargin = dp(5);
        titleBlock.addView(subtitle, subtitleParams);
        heroTop.addView(titleBlock, new LinearLayout.LayoutParams(0, -2, 1));

        TextView close = text("×", 28, WHITE, false);
        close.setGravity(Gravity.CENTER);
        close.setBackground(rounded(PijarStyle.PURPLE, 13));
        heroTop.addView(close, new LinearLayout.LayoutParams(dp(38), dp(38)));
        close.setOnClickListener(v -> dialog.dismiss());
        hero.addView(heroTop);

        TextView overview = text(
                "Semua informasi penting Pijar Karier akan tampil di sini.",
                13, Color.rgb(235, 238, 255), false
        );
        LinearLayout.LayoutParams overviewParams = new LinearLayout.LayoutParams(-1, -2);
        overviewParams.topMargin = dp(18);
        hero.addView(overview, overviewParams);
        panel.addView(hero);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(18), dp(18), dp(20));
        body.addView(text("Pembaruan terbaru", 16, TEXT, true));

        addNotificationItem(body, "✦", "Rekomendasi pekerjaan",
                "Jelajahi lowongan yang sesuai dengan minat dan kategori pilihanmu.",
                Color.rgb(235, 239, 255));
        addNotificationItem(body, "✓", "Aktivitas lamaran",
                "Pantau proses rekrutmen dari halaman Lamaran saya.",
                Color.rgb(230, 248, 240));
        addNotificationItem(body, "♥", "Pekerjaan favorit",
                "Simpan lowongan dengan ikon hati agar mudah ditemukan kembali.",
                Color.rgb(255, 238, 242));

        TextView note = text(
                "Belum ada notifikasi baru dari server.",
                12, MUTED, false
        );
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(8), 0, dp(14));
        body.addView(note);

        TextView explore = text("Jelajahi Lowongan  →", 14, WHITE, true);
        explore.setGravity(Gravity.CENTER);
        explore.setPadding(dp(14), dp(15), dp(14), dp(15));
        explore.setBackground(rounded(BLUE, 15));
        body.addView(explore, new LinearLayout.LayoutParams(-1, -2));
        explore.setOnClickListener(v -> {
            dialog.dismiss();
            renderPage("Eksplorasi");
        });

        panel.addView(body);
        ScrollView panelScroll = new ScrollView(this);
        panelScroll.addView(panel);
        dialog.setContentView(panelScroll);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }
        UiMotion.styleButtons(panel);
        UiMotion.bindActions(panel);
        dialog.show();
        UiMotion.revealChildren(body, 40, 65, 6);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    getResources().getDisplayMetrics().widthPixels - dp(32),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }
    }

    private void addNotificationItem(
            LinearLayout parent,
            String symbol,
            String title,
            String description,
            int iconBackground
    ) {
        LinearLayout item = row();
        item.setGravity(Gravity.TOP);
        item.setPadding(dp(12), dp(13), dp(12), dp(13));
        item.setBackground(rounded(BACKGROUND, 17));

        if ("♥".equals(symbol) || "♡".equals(symbol)) {
            ImageView icon = new ImageView(this);
            icon.setImageResource(R.drawable.ic_favorite);
            icon.setColorFilter(BLUE);
            icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            icon.setPadding(dp(11), dp(11), dp(11), dp(11));
            icon.setBackground(rounded(iconBackground, 13));
            item.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        } else {
            TextView icon = text(symbol, 19, BLUE, true);
            icon.setGravity(Gravity.CENTER);
            icon.setBackground(rounded(iconBackground, 13));
            item.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
        }

        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setPadding(dp(11), 0, 0, 0);
        words.addView(text(title, 13, TEXT, true));
        TextView detail = text(description, 11, MUTED, false);
        detail.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(-1, -2);
        detailParams.topMargin = dp(5);
        words.addView(detail, detailParams);
        item.addView(words, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(-1, -2);
        itemParams.topMargin = dp(11);
        parent.addView(item, itemParams);
    }

    private void showMessage(String title, String message) {
        Dialog dialog = new Dialog(this);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(22), dp(22), dp(22), dp(20));
        panel.setBackground(rounded(WHITE, 24));
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_lk_info_outline);
        icon.setPadding(dp(11), dp(11), dp(11), dp(11));
        icon.setBackground(rounded(BLUE_LIGHT, 16));
        panel.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView heading = text(title, 20, TEXT, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2); hp.topMargin = dp(15);
        panel.addView(heading, hp);
        TextView body = text(message, 14, MUTED, false); body.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = dp(10);
        panel.addView(body, bp);
        TextView ok = text("Mengerti", 14, WHITE, true); ok.setGravity(Gravity.CENTER);
        ok.setBackground(rounded(BLUE, 15)); ok.setOnClickListener(v -> dialog.dismiss());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, dp(50)); op.topMargin = dp(20);
        panel.addView(ok, op);
        ScrollView scroll = new ScrollView(this); scroll.addView(panel);
        dialog.setContentView(scroll); dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(Math.min(getResources().getDisplayMetrics().widthPixels - dp(36), dp(400)), -2);
        }
        UiMotion.bindActions(panel); UiMotion.revealChildren(panel, 40, 60, 4);
    }

    private void toast(String message) {
        Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
        ).show();
    }
}
