package com.example.lokerku;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class NetworkView extends View {

    private final Paint particlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();

    private int width;
    private int height;

    private final float connectionDistance = 210f;

    public NetworkView(Context context) {
        super(context);
        init();
    }

    public NetworkView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public NetworkView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {

        particlePaint.setStyle(Paint.Style.FILL);

        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(1.2f);

        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {

        width = w;
        height = h;

        particles.clear();

        int count = Math.max(28, Math.min(55, width / 18));

        for (int i = 0; i < count; i++) {

            Particle particle = new Particle();

            particle.x = random.nextFloat() * width;
            particle.y = random.nextFloat() * height;

            particle.speedX = (random.nextFloat() - 0.5f) * 0.65f;
            particle.speedY = (random.nextFloat() - 0.5f) * 0.65f;

            particle.radius = 1.5f + random.nextFloat() * 2.8f;

            particle.alpha = 80 + random.nextInt(130);

            particles.add(particle);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {

        super.onDraw(canvas);

        updateParticles();

        drawConnections(canvas);
        drawParticles(canvas);

        postInvalidateDelayed(16);
    }

    private void updateParticles() {

        for (Particle particle : particles) {

            particle.x += particle.speedX;
            particle.y += particle.speedY;

            if (particle.x < -20) {
                particle.x = width + 20;
            }

            if (particle.x > width + 20) {
                particle.x = -20;
            }

            if (particle.y < -20) {
                particle.y = height + 20;
            }

            if (particle.y > height + 20) {
                particle.y = -20;
            }

            particle.pulse += 0.035f;
        }
    }

    private void drawConnections(Canvas canvas) {

        for (int i = 0; i < particles.size(); i++) {

            Particle first = particles.get(i);

            for (int j = i + 1; j < particles.size(); j++) {

                Particle second = particles.get(j);

                float dx = first.x - second.x;
                float dy = first.y - second.y;

                float distance = (float) Math.sqrt(
                        dx * dx + dy * dy
                );

                if (distance < connectionDistance) {

                    float alpha =
                            (1f - distance / connectionDistance) * 85f;

                    linePaint.setColor(
                            android.graphics.Color.argb(
                                    (int) alpha,
                                    65,
                                    150,
                                    230
                            )
                    );

                    canvas.drawLine(
                            first.x,
                            first.y,
                            second.x,
                            second.y,
                            linePaint
                    );
                }
            }
        }
    }

    private void drawParticles(Canvas canvas) {

        for (Particle particle : particles) {

            float pulse =
                    (float) Math.sin(particle.pulse) * 0.8f;

            float radius = particle.radius + pulse;

            particlePaint.setColor(
                    android.graphics.Color.argb(
                            particle.alpha,
                            96,
                            165,
                            250
                    )
            );

            particlePaint.setShadowLayer(
                    10f,
                    0,
                    0,
                    android.graphics.Color.argb(
                            particle.alpha,
                            37,
                            99,
                            235
                    )
            );

            canvas.drawCircle(
                    particle.x,
                    particle.y,
                    Math.max(0.8f, radius),
                    particlePaint
            );
        }

        particlePaint.clearShadowLayer();
    }

    private static class Particle {

        float x;
        float y;

        float speedX;
        float speedY;

        float radius;
        int alpha;

        float pulse;
    }
}