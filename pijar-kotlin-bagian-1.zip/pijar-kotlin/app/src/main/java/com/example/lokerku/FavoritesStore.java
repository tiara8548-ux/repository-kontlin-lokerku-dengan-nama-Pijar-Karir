package com.example.lokerku;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;
final class FavoritesStore {
    private FavoritesStore(){}
    static String name(Context c){return "lokerku_favorites_"+c.getSharedPreferences("lokerku_user",Context.MODE_PRIVATE).getInt("id",0);}
    static void migrate(Context c,int previousUser,int newUser){
        if(previousUser<=0 || previousUser!=newUser)return;
        SharedPreferences old=c.getSharedPreferences("lokerku_favorites",Context.MODE_PRIVATE);
        SharedPreferences scoped=c.getSharedPreferences("lokerku_favorites_"+newUser,Context.MODE_PRIVATE);
        SharedPreferences oldNotes=c.getSharedPreferences("lokerku_notes",Context.MODE_PRIVATE);
        SharedPreferences newNotes=c.getSharedPreferences("lokerku_notes_"+newUser,Context.MODE_PRIVATE);
        if (!newNotes.contains("notes") && oldNotes.contains("notes")) {
            newNotes.edit().putString("notes",oldNotes.getString("notes","")).apply();oldNotes.edit().clear().apply();
        }
        if(!scoped.contains("job_ids") && old.contains("job_ids")){
            Set<String> values=old.getStringSet("job_ids",new HashSet<>());
            scoped.edit().putStringSet("job_ids",new HashSet<>(values)).apply();old.edit().clear().apply();
        }
    }
}
