package com.example.lokerku

import android.app.Activity
import android.content.Intent
import android.os.CancellationSignal
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.GetCredentialException
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import org.json.JSONObject

/** Existing nonce and token exchange, migrated without changing the API contract. */
object GoogleSignInFlow {
    private const val BASE = "https://ahannaja.cu.ma/lokerku_api/"
    private const val CLIENT = "579438749291-sdlee32ci5m8e1rjf0506o3b2gj2asus.apps.googleusercontent.com"
    interface FreshCredential { fun ready(token: String, nonce: String); fun fail(message: String) }

    @JvmStatic fun fresh(activity: Activity, callback: FreshCredential) {
        val req = StringRequest(Request.Method.POST, BASE + "auth/google_nonce.php", { response ->
            try {
                val json = JSONObject(response)
                val nonce = json.optString("nonce", "")
                if (!json.optBoolean("success") || !nonce.matches(Regex("[a-f0-9]{64}"))) {
                    callback.fail("Server belum siap untuk Google.")
                } else {
                    val option = GetSignInWithGoogleOption.Builder(CLIENT).setNonce(nonce).build()
                    val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                    CredentialManager.create(activity).getCredentialAsync(
                        activity, request, CancellationSignal(), ContextCompat.getMainExecutor(activity),
                        object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                            override fun onResult(result: GetCredentialResponse) {
                                try {
                                    val credential = result.credential
                                    if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                        callback.fail("Kredensial Google tidak dikenali."); return
                                    }
                                    callback.ready(GoogleIdTokenCredential.createFrom(credential.data).idToken, nonce)
                                } catch (e: Exception) { callback.fail("Tidak dapat membaca akun Google.") }
                            }
                            override fun onError(e: GetCredentialException) {
                                callback.fail("Google belum dapat dibuka (${e.javaClass.simpleName}). Periksa akun Google dan Play Services.")
                            }
                        })
                }
            } catch (e: Exception) { callback.fail("Respons server tidak valid.") }
        }, { callback.fail("Tidak dapat menghubungi server untuk Google.") })
        req.retryPolicy = DefaultRetryPolicy(15000, 0, 1f)
        Volley.newRequestQueue(activity.applicationContext).add(req)
    }

    @JvmStatic fun signIn(activity: Activity, register: Boolean, onFinished: Runnable) {
        fresh(activity, object : FreshCredential {
            override fun fail(message: String) {
                onFinished.run(); Toast.makeText(activity, message, Toast.LENGTH_LONG).show()
            }
            override fun ready(idToken: String, nonce: String) {
                val req = object : StringRequest(Method.POST, BASE + "auth/google.php", { response ->
                    try {
                        val json = JSONObject(response)
                        if (!json.optBoolean("success")) {
                            fail(json.optString("message", "Gagal masuk Google."))
                        } else {
                            saveUser(activity, json.getJSONObject("user"), json.getString("session_token"))
                            val intent = Intent(activity, MainActivity::class.java)
                                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            activity.startActivity(intent); activity.finish()
                        }
                    } catch (e: Exception) { fail("Tidak dapat menyimpan sesi. Silakan coba lagi.") }
                }, { error ->
                    var message = "Tidak dapat menghubungi server."
                    val data = error.networkResponse?.data
                    if (data != null) try {
                        message = JSONObject(String(data, Charsets.UTF_8)).optString("message", message)
                    } catch (_: Exception) { }
                    fail(message)
                }) {
                    override fun getParams(): MutableMap<String, String> = hashMapOf(
                        "mode" to if (register) "register" else "login",
                        "id_token" to idToken, "nonce" to nonce
                    )
                }
                req.retryPolicy = DefaultRetryPolicy(20000, 0, 1f)
                Volley.newRequestQueue(activity.applicationContext).add(req)
            }
        })
    }

    @JvmStatic @Throws(Exception::class)
    fun saveUser(activity: Activity, user: JSONObject, token: String) {
        if (user.optInt("id", 0) <= 0 || !token.matches(Regex("[a-f0-9]{64}"))) throw Exception("invalid session")
        SessionStore.save(activity, token)
        val p = activity.getSharedPreferences("lokerku_user", Activity.MODE_PRIVATE)
        FavoritesStore.migrate(activity, p.getInt("id", 0), user.getInt("id"))
        p.edit().clear().putInt("id",user.getInt("id"))
            .putString("nama",value(user,"nama")).putString("username",value(user,"username"))
            .putString("email",value(user,"email")).putString("phone",value(user,"no_hp"))
            .putString("foto",value(user,"foto")).putString("role",value(user,"role"))
            .putString("profile_headline",value(user,"profile_headline")).putString("profile_lokasi",value(user,"profile_lokasi"))
            .putString("profile_bio",value(user,"profile_bio")).putString("profile_linkedin",value(user,"profile_linkedin"))
            .putString("profile_portfolio",value(user,"profile_portfolio")).apply()
    }
    private fun value(json: JSONObject, key: String) = if (json.isNull(key)) "" else json.optString(key, "")
}
